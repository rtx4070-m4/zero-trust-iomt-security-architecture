# Keycloak IAM Setup for Zero Trust IoMT
## Identity Provider Configuration Guide

---

## Overview

This guide configures Keycloak as the Identity Provider (IdP) for the Zero Trust IoMT platform. Keycloak acts as the centralized authentication and authorization server, issuing JWTs that are validated by the ZTA Gateway.

**Architecture Role:**  
`IoMT Device / User` → `Keycloak (IdP/STS)` → `JWT Token` → `ZTA Gateway (PEP)` → `Backend Service`

---

## Prerequisites

- Docker + Docker Compose
- Keycloak 23.x (bundled in docker-compose.yml)
- Realm admin credentials (set in .env)

---

## Quick Start (Docker)

```bash
# Start Keycloak
docker-compose up -d keycloak

# Wait for startup (~60 seconds)
# Access admin console at: http://localhost:8080/admin
# Default credentials: admin / AdminPassword123!

# Import pre-configured realm (optional)
docker exec keycloak /opt/keycloak/bin/kc.sh import \
  --file /opt/keycloak/data/import/iomt-realm.json
```

---

## Realm Configuration

### 1. Create Realm

```
Realm Name: iomt-zerotrust
Display Name: IoMT Zero Trust Platform
Enabled: ON
```

### 2. Configure Token Settings

```
# In: Realm Settings → Tokens

Access Token Lifespan:          300  seconds (5 min — short-lived)
Refresh Token Max Reuse:        0
SSO Session Idle:               1800 seconds (30 min)
SSO Session Max:                28800 seconds (8 hours)
Offline Session Idle Timeout:   0    (disabled for medical devices)

# JWT Algorithm
Default Signature Algorithm: RS256
```

### 3. Create Client (ZTA Gateway)

```
Client ID:              zta-gateway
Client Type:            confidential
Authorization Enabled:  ON
Service Account:        ON
Direct Access Grants:   OFF (use device auth flow only)
Root URL:               https://zta-gateway.hospital.local:8000
```

**Client Secret:** Generate a 32-byte random secret and store in Vault.

### 4. Create Client (IoMT Devices)

```
Client ID:     iomt-devices
Client Type:   confidential
Grant Types:   client_credentials (device-to-device, machine identity)
               device_authorization_grant (for interactive setup)
```

---

## Client Scopes

Create the following custom scopes to map device/user attributes to JWT claims:

```json
{
  "name": "iomt-device",
  "protocol": "openid-connect",
  "attributes": {
    "device_id": "${device.device_id}",
    "device_role": "${device.role}",
    "vlan": "${device.vlan}",
    "trust_score": "${device.trust_score}"
  }
}
```

---

## User Configuration

### Create Users via CLI

```bash
# Connect to Keycloak container
docker exec -it keycloak bash

# Create physician user
/opt/keycloak/bin/kcadm.sh create users \
  -r iomt-zerotrust \
  -s username=dr.sarah.chen \
  -s email=sarah.chen@hospital.local \
  -s firstName=Sarah \
  -s lastName=Chen \
  -s enabled=true \
  -s "attributes.employee_id=[\"EMP-10042\"]" \
  -s "attributes.department=[\"ICU\"]"

# Set password
/opt/keycloak/bin/kcadm.sh set-password \
  -r iomt-zerotrust \
  --username dr.sarah.chen \
  --new-password 'TempPass#2025!'

# Assign role
/opt/keycloak/bin/kcadm.sh add-roles \
  -r iomt-zerotrust \
  --uusername dr.sarah.chen \
  --rolename physician
```

### Roles to Create

```bash
for ROLE in physician nurse radiologist biomedical_engineer it_admin \
            security_analyst readonly_auditor device_iomt; do
  /opt/keycloak/bin/kcadm.sh create roles \
    -r iomt-zerotrust \
    -s name="$ROLE" \
    -s "description=IoMT Zero Trust role: $ROLE"
done
```

---

## MFA Configuration

### Enable TOTP (Google Authenticator / Authy)

```
Realm Settings → Authentication → OTP Policy:
  Type:              totp
  Algorithm:         SHA256
  Digits:            6
  Period:            30 seconds
  Initial Counter:   0

Authentication Flows → Browser:
  Add step: OTP Form (REQUIRED for physician, nurse, it_admin, security_analyst)
```

### FIDO2 / WebAuthn (for privileged roles)

```
Authentication → WebAuthn Policy:
  Relying Party Name:     hospital.local
  Signature Algorithms:   ES256, RS256
  Attestation:            required (for admin roles)
  Resident Key:           preferred
  User Verification:      required
```

---

## Device Authentication (mTLS + Client Certificates)

IoMT devices authenticate using mutual TLS (mTLS) rather than username/password.

### Configure mTLS in Keycloak

```
Realm Settings → Advanced:
  X.509 Client Certificate Bound Access Tokens: ON

Client (iomt-devices) → Credentials:
  Client Authenticator: X509 Certificate
  Subject DN: O=Hospital Medical Devices, OU=ICU, CN=${device_id}
```

### Device Certificate Template (OpenSSL)

```bash
# Generate device private key
openssl genrsa -out device-IP-001.key 4096

# Generate CSR
openssl req -new -key device-IP-001.key \
  -subj "/O=Hospital Medical Devices/OU=ICU/CN=IP-001" \
  -out device-IP-001.csr

# Sign with hospital CA
openssl x509 -req -in device-IP-001.csr \
  -CA hospital-ca.crt -CAkey hospital-ca.key \
  -CAcreateserial \
  -out device-IP-001.crt \
  -days 365 \
  -extensions v3_req \
  -extfile <(cat << EOF
[v3_req]
subjectAltName = URI:urn:iomt:device:IP-001
keyUsage = critical,digitalSignature,keyEncipherment
extendedKeyUsage = clientAuth
EOF
)

echo "Certificate thumbprint:"
openssl x509 -in device-IP-001.crt -fingerprint -sha256 -noout
```

---

## JWT Token Validation (ZTA Gateway)

The ZTA Gateway validates JWTs issued by Keycloak on every request:

```python
import jwt
from jwt.algorithms import RSAAlgorithm
import requests

KEYCLOAK_URL = "http://keycloak:8080"
REALM        = "iomt-zerotrust"
JWKS_URI     = f"{KEYCLOAK_URL}/realms/{REALM}/protocol/openid-connect/certs"

def validate_token(token: str) -> dict:
    """Validate a Keycloak JWT and return claims."""
    # Fetch JWKS (cache this in production)
    jwks = requests.get(JWKS_URI).json()
    
    # Find the matching key by 'kid' header
    headers = jwt.get_unverified_header(token)
    key = next(k for k in jwks["keys"] if k["kid"] == headers["kid"])
    public_key = RSAAlgorithm.from_jwk(key)
    
    claims = jwt.decode(
        token,
        public_key,
        algorithms=["RS256"],
        audience="zta-gateway",
        issuer=f"{KEYCLOAK_URL}/realms/{REALM}",
        options={"verify_exp": True},
    )
    
    # Validate required claims
    assert "device_id" in claims or "preferred_username" in claims
    assert "realm_access" in claims
    
    return claims
```

---

## RBAC Policy Enforcement

Map Keycloak roles to ZTA permissions using the RBAC config:

```python
from typing import List

ROLE_PERMISSIONS = {
    "physician":             ["ehr:*:read", "ehr:medications:write", "monitor:*:read"],
    "nurse":                 ["ehr:records:read", "monitor:*:read", "monitor:vitals:write"],
    "it_admin":              ["admin:*", "device:quarantine", "zta:policies:modify"],
    "security_analyst":      ["audit:*:read", "device:quarantine", "zta:alerts:*"],
    "biomedical_engineer":   ["device:*:read", "device:*:maintenance"],
    "device_iomt":           ["ehr:telemetry:write", "zta:gateway:authenticate"],
}

def has_permission(claims: dict, required_permission: str) -> bool:
    """Check if token claims include the required permission."""
    roles = claims.get("realm_access", {}).get("roles", [])
    for role in roles:
        perms = ROLE_PERMISSIONS.get(role, [])
        for perm in perms:
            if _permission_matches(perm, required_permission):
                return True
    return False

def _permission_matches(pattern: str, permission: str) -> bool:
    """Simple wildcard permission matching."""
    if pattern == permission:
        return True
    if pattern.endswith(":*"):
        prefix = pattern[:-1]
        return permission.startswith(prefix)
    return False
```

---

## Event Logging / Audit

```
Realm Settings → Events → Event Settings:
  Save Events: ON
  Events Expiration: 90 days
  Saved Event Types:
    - LOGIN
    - LOGIN_ERROR
    - LOGOUT
    - CLIENT_LOGIN
    - CLIENT_LOGIN_ERROR
    - TOKEN_EXCHANGE
    - REVOKE_GRANT
    - UPDATE_PASSWORD
```

---

## Production Hardening Checklist

- [ ] Change all default passwords (admin, service accounts)
- [ ] Enable TLS 1.2+ only on Keycloak HTTPS listener
- [ ] Configure HSTS headers
- [ ] Enable brute-force protection (max 5 failures, 30-min lockout)
- [ ] Disable user self-registration
- [ ] Enable token introspection endpoint
- [ ] Configure LDAP/AD integration for user provisioning
- [ ] Set up Keycloak HA (2+ nodes + PostgreSQL)
- [ ] Configure backup/restore procedure for realm
- [ ] Integrate with SIEM for event log forwarding
- [ ] Periodic access review schedule (quarterly)
- [ ] Implement Keycloak Admin REST API monitoring

---

## Compliance Mappings

| Keycloak Feature | HIPAA Control | NIST Control |
|---|---|---|
| MFA enforcement | § 164.312(d) | IA-2(1) |
| Session timeout | § 164.312(a)(2)(iii) | AC-12 |
| Audit logging | § 164.312(b) | AU-2 |
| Unique user IDs | § 164.312(a)(2)(i) | IA-4 |
| Automatic logoff | § 164.312(a)(2)(iii) | AC-12 |
| Encryption in transit | § 164.312(e)(1) | SC-8 |
