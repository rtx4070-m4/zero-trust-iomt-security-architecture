"""
gateway.py — Zero Trust API Gateway (FastAPI)
==============================================
Acts as the Policy Enforcement Point (PEP) for all IoMT API requests.
All requests must pass Zero Trust policy evaluation before being proxied
to backend services (EHR, device management, monitoring APIs).

Endpoints:
  POST /api/v1/request       — Submit an IoMT communication request
  GET  /api/v1/device/{id}   — Get device info (requires auth)
  POST /api/v1/auth/token    — Obtain a bearer token (mock IAM)
  GET  /api/v1/policies      — List active Zero Trust policies
  GET  /api/v1/health        — Gateway health check
  GET  /api/v1/audit         — Recent audit log entries

Run:
    uvicorn api.gateway:app --host 0.0.0.0 --port 8000 --reload

Test:
    curl -X POST http://localhost:8000/api/v1/auth/token \
         -H "Content-Type: application/json" \
         -d '{"device_id": "PM-001", "cert_thumbprint": "SHA256:d4e5f6..."}'

    curl -X POST http://localhost:8000/api/v1/request \
         -H "Authorization: Bearer <token>" \
         -H "Content-Type: application/json" \
         -d '{"src_device_id": "PM-001", "dst_ip": "10.0.99.20", "dst_port": 443, "payload_type": "fhir-r4-vitals"}'
"""

import os
import sys
import json
import hashlib
import secrets
import time
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any, List

# FastAPI imports — graceful fallback if not installed
try:
    from fastapi import FastAPI, HTTPException, Depends, Request, status
    from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel, Field
    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False
    print("[WARNING] FastAPI not installed. Run: pip install fastapi uvicorn")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

if FASTAPI_AVAILABLE:
    from simulation.topology import IoMTTopology
    from policies.policy_engine import ZeroTrustPolicyEngine
    from monitoring.logger import IoMTLogger
    from simulation.iomt_sim import Packet

# ── Mock Token Store ──────────────────────────────────────────────────────────

_token_store: Dict[str, Dict] = {}   # token → {device_id, issued_at, expires_at}
TOKEN_TTL_SECONDS = 3600             # 1 hour


# ── Pydantic Models ───────────────────────────────────────────────────────────

if FASTAPI_AVAILABLE:

    class AuthRequest(BaseModel):
        device_id: str = Field(..., description="Registered device ID (e.g., PM-001)")
        cert_thumbprint: str = Field(..., description="SHA256 certificate thumbprint")
        user_id: Optional[str] = Field(None, description="Optional user ID for user-context auth")

    class CommunicationRequest(BaseModel):
        src_device_id: str = Field(..., description="Source device ID")
        dst_ip: str = Field(..., description="Destination IP address")
        dst_port: int = Field(..., ge=1, le=65535, description="Destination TCP/UDP port")
        protocol: str = Field("TCP", description="Network protocol")
        payload_type: str = Field("generic", description="Payload/content type descriptor")
        payload_size: int = Field(512, ge=0, description="Payload size in bytes")

    class PolicyUpdateRequest(BaseModel):
        device_id: str
        action: str  # "quarantine" | "authorize" | "set_trust_score"
        value: Optional[Any] = None
        reason: str = "manual_update"

# ── App Initialization ────────────────────────────────────────────────────────

if FASTAPI_AVAILABLE:
    app = FastAPI(
        title="Zero Trust IoMT API Gateway",
        description=(
            "Policy Enforcement Point (PEP) for Internet of Medical Things (IoMT) devices. "
            "Implements NIST SP 800-207 Zero Trust Architecture."
        ),
        version="2.1.0",
        contact={
            "name": "Security Engineering Team",
            "email": "security@hospital.example.com",
        },
        license_info={"name": "MIT"},
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Singletons
    _topology      = IoMTTopology()
    _policy_engine = ZeroTrustPolicyEngine(_topology)
    _logger        = IoMTLogger(console_output=False)
    _security      = HTTPBearer(auto_error=False)
    _audit_log: List[Dict] = []


# ── Auth Helper ────────────────────────────────────────────────────────────────

def _issue_token(device_id: str) -> str:
    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    _token_store[token] = {
        "device_id": device_id,
        "issued_at": now.isoformat(),
        "expires_at": (now + timedelta(seconds=TOKEN_TTL_SECONDS)).isoformat(),
    }
    return token


def _validate_token(token: str) -> Optional[Dict]:
    if token not in _token_store:
        return None
    info = _token_store[token]
    expires = datetime.fromisoformat(info["expires_at"])
    if datetime.now(timezone.utc) > expires:
        del _token_store[token]
        return None
    return info


def _get_current_device(
    credentials: HTTPAuthorizationCredentials = Depends(_security if FASTAPI_AVAILABLE else None),
) -> Dict:
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing Bearer token. Obtain one via POST /api/v1/auth/token",
        )
    info = _validate_token(credentials.credentials)
    if info is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
        )
    return info


def _audit(action: str, device_id: str, result: str, details: Dict = None):
    _audit_log.append({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "action": action,
        "device_id": device_id,
        "result": result,
        "details": details or {},
    })
    if len(_audit_log) > 1000:
        _audit_log.pop(0)


# ── Routes ────────────────────────────────────────────────────────────────────

if FASTAPI_AVAILABLE:

    @app.get("/api/v1/health", tags=["System"])
    async def health_check():
        """Gateway health check endpoint."""
        return {
            "status": "healthy",
            "service": "Zero Trust IoMT Gateway",
            "version": "2.1.0",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "registered_devices": len(_topology.devices),
            "active_tokens": len(_token_store),
        }

    @app.post("/api/v1/auth/token", tags=["Authentication"])
    async def obtain_token(auth_req: AuthRequest):
        """
        Obtain a bearer token for device-to-gateway communication.

        The device must be registered and present a valid certificate thumbprint.
        On success, returns a time-limited Bearer token (TTL: 1 hour).
        """
        device = _topology.get_device(auth_req.device_id)

        if device is None:
            _audit("AUTH", auth_req.device_id, "REJECTED_UNKNOWN_DEVICE")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Device '{auth_req.device_id}' not found in registry",
            )

        if not device.authorized:
            _audit("AUTH", auth_req.device_id, "REJECTED_UNAUTHORIZED")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Device authorization has been revoked",
            )

        if device.cert_thumbprint != auth_req.cert_thumbprint:
            _audit("AUTH", auth_req.device_id, "REJECTED_CERT_MISMATCH")
            _logger.log_auth_event(
                auth_req.user_id or "device",
                auth_req.device_id,
                success=False,
                method="cert_thumbprint",
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Certificate thumbprint mismatch",
            )

        if device.compromised:
            _audit("AUTH", auth_req.device_id, "REJECTED_COMPROMISED")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Device is quarantined due to compromise detection",
            )

        token = _issue_token(auth_req.device_id)
        _audit("AUTH", auth_req.device_id, "TOKEN_ISSUED")
        _logger.log_auth_event(
            auth_req.user_id or "device",
            auth_req.device_id,
            success=True,
            method="cert_thumbprint",
        )

        return {
            "access_token": token,
            "token_type": "bearer",
            "expires_in": TOKEN_TTL_SECONDS,
            "device_id": auth_req.device_id,
            "trust_score": device.trust_score,
        }

    @app.post("/api/v1/request", tags=["Zero Trust Enforcement"])
    async def evaluate_communication_request(
        comm_req: CommunicationRequest,
        token_info: Dict = Depends(_get_current_device),
    ):
        """
        Evaluate a device communication request against Zero Trust policies.

        The source device must match the authenticated token. All policy checks
        are applied via the Policy Engine. Requests that pass all checks are
        forwarded; others are denied with the blocking policy reason.
        """
        # Token device must match src device
        if token_info["device_id"] != comm_req.src_device_id:
            _audit("REQUEST", comm_req.src_device_id, "REJECTED_TOKEN_MISMATCH",
                   {"token_device": token_info["device_id"]})
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Token device does not match src_device_id",
            )

        # Build packet and evaluate
        packet = Packet(
            src_device_id=comm_req.src_device_id,
            dst_ip=comm_req.dst_ip,
            dst_port=comm_req.dst_port,
            protocol=comm_req.protocol,
            payload_size=comm_req.payload_size,
            payload_type=comm_req.payload_type,
        )

        decision = _policy_engine.evaluate(packet)
        allowed   = decision["allowed"]
        reason    = decision["reason"]
        src_device = _topology.get_device(comm_req.src_device_id)

        if allowed:
            _audit("REQUEST", comm_req.src_device_id, "ALLOWED",
                   {"dst_ip": comm_req.dst_ip, "dst_port": comm_req.dst_port})
            _logger.log_allow(packet, src_device.ip if src_device else "?", reason)
            _logger.flush()
            return {
                "decision": "ALLOW",
                "reason": reason,
                "src_device_id": comm_req.src_device_id,
                "dst_ip": comm_req.dst_ip,
                "dst_port": comm_req.dst_port,
                "policy_id": decision.get("policy_id"),
                "timestamp": decision.get("timestamp"),
            }
        else:
            _audit("REQUEST", comm_req.src_device_id, "DENIED",
                   {"reason": reason, "dst_ip": comm_req.dst_ip})
            threat = decision.get("threat_level", "HIGH")
            _logger.log_deny(
                packet,
                src_device.ip if src_device else "?",
                reason,
                threat_level=threat,
            )
            _logger.flush()
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "decision": "DENY",
                    "reason": reason,
                    "policy_id": decision.get("policy_id"),
                    "threat_level": threat,
                    "timestamp": decision.get("timestamp"),
                },
            )

    @app.get("/api/v1/device/{device_id}", tags=["Device Management"])
    async def get_device_info(
        device_id: str,
        token_info: Dict = Depends(_get_current_device),
    ):
        """Retrieve device information from the ZTA device registry."""
        device = _topology.get_device(device_id)
        if device is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Device '{device_id}' not found",
            )
        return device.to_dict()

    @app.get("/api/v1/devices", tags=["Device Management"])
    async def list_devices(
        token_info: Dict = Depends(_get_current_device),
        role: Optional[str] = None,
    ):
        """List all registered IoMT devices, optionally filtered by role."""
        devices = list(_topology.devices.values())
        if role:
            devices = [d for d in devices if d.role == role]
        return {
            "total": len(devices),
            "devices": [d.to_dict() for d in devices],
        }

    @app.post("/api/v1/device/action", tags=["Device Management"])
    async def device_action(
        req: PolicyUpdateRequest,
        token_info: Dict = Depends(_get_current_device),
    ):
        """
        Perform a security action on a device:
          - quarantine: Revoke device authorization and flag as compromised
          - authorize:  Restore device authorization
          - set_trust_score: Update device trust score (float 0.0–1.0)
        """
        device = _topology.get_device(req.device_id)
        if device is None:
            raise HTTPException(status_code=404, detail="Device not found")

        result = {}

        if req.action == "quarantine":
            device.authorized = False
            device.compromised = True
            device.trust_score = 0.0
            _logger.log_device_quarantined(req.device_id, req.reason)
            result = {"action": "quarantine", "device_id": req.device_id, "status": "quarantined"}

        elif req.action == "authorize":
            device.authorized = True
            device.compromised = False
            device.trust_score = 0.8
            result = {"action": "authorize", "device_id": req.device_id, "status": "authorized"}

        elif req.action == "set_trust_score":
            score = float(req.value)
            if not 0.0 <= score <= 1.0:
                raise HTTPException(status_code=400, detail="Trust score must be 0.0–1.0")
            device.trust_score = score
            result = {"action": "set_trust_score", "device_id": req.device_id,
                      "trust_score": score}

        else:
            raise HTTPException(status_code=400, detail=f"Unknown action: {req.action}")

        _audit("DEVICE_ACTION", req.device_id, req.action.upper(),
               {"reason": req.reason, "value": req.value})
        return result

    @app.get("/api/v1/policies", tags=["Policy Management"])
    async def list_policies(token_info: Dict = Depends(_get_current_device)):
        """List all active Zero Trust policies."""
        return {
            "total_policies": 10,
            "policies": [
                {"id": "P01", "name": "Device Registry Check",
                 "description": "Device must be in authorized registry"},
                {"id": "P02", "name": "Authorization Status",
                 "description": "Device authorization flag must be active"},
                {"id": "P03", "name": "Trust Score Threshold",
                 "description": "Device trust score >= 0.5"},
                {"id": "P04", "name": "Certificate Validation",
                 "description": "Valid X.509 certificate required"},
                {"id": "P05", "name": "Compromise Quarantine",
                 "description": "Compromised devices denied immediately"},
                {"id": "P06", "name": "Port Allow-list",
                 "description": "Only pre-approved destination ports permitted"},
                {"id": "P07", "name": "Destination Allow-list",
                 "description": "Only pre-approved destination IPs permitted"},
                {"id": "P08", "name": "Cross-Segment Restriction",
                 "description": "Micro-segmentation enforced per VLAN"},
                {"id": "P09", "name": "Payload Signature Detection",
                 "description": "Malicious payload signatures blocked"},
                {"id": "P10", "name": "High-Risk Port Elevation",
                 "description": "Privileged ports require elevated device role"},
            ],
        }

    @app.get("/api/v1/audit", tags=["Audit"])
    async def get_audit_log(
        limit: int = 50,
        token_info: Dict = Depends(_get_current_device),
    ):
        """Retrieve recent audit log entries."""
        return {
            "total": len(_audit_log),
            "returned": min(limit, len(_audit_log)),
            "entries": _audit_log[-limit:][::-1],
        }


# ── Startup / Fallback ────────────────────────────────────────────────────────

if not FASTAPI_AVAILABLE:
    print("FastAPI not available. Install with: pip install fastapi uvicorn")
    print("Then run: uvicorn api.gateway:app --host 0.0.0.0 --port 8000")
