"""
logger.py — IoMT Security Event Logger
=======================================
Structured JSON-lines logger for all ZTA policy decisions,
security events, and anomaly detections.

Log levels: DEBUG | INFO | WARNING | ALERT | CRITICAL

Output:
  logs/iomt_events.jsonl   — All events (JSON Lines)
  logs/security.log        — Human-readable security log
  logs/denied.jsonl        — Denied packets only
"""

import os
import json
import logging
import sys
from datetime import datetime, timezone
from typing import Optional, Dict, Any

# ── Log Directories ────────────────────────────────────────────────────────────

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

# ── ANSI Colors ────────────────────────────────────────────────────────────────
GREEN   = "\033[92m"
RED     = "\033[91m"
YELLOW  = "\033[93m"
CYAN    = "\033[96m"
MAGENTA = "\033[95m"
BOLD    = "\033[1m"
DIM     = "\033[2m"
RESET   = "\033[0m"

# ── Event Severity Mapping ─────────────────────────────────────────────────────
SEVERITY_COLORS = {
    "INFO":     GREEN,
    "WARNING":  YELLOW,
    "ALERT":    MAGENTA,
    "CRITICAL": RED,
    "DEBUG":    DIM,
}

THREAT_SEVERITY = {
    "NONE":     "INFO",
    "LOW":      "INFO",
    "MEDIUM":   "WARNING",
    "HIGH":     "ALERT",
    "CRITICAL": "CRITICAL",
}


class IoMTLogger:
    """
    Structured security event logger for the IoMT ZTA simulation.
    Writes JSON Lines to file and formatted output to console.
    """

    def __init__(
        self,
        events_file: str = "iomt_events.jsonl",
        denied_file: str = "denied.jsonl",
        security_log: str = "security.log",
        console_output: bool = True,
        min_console_level: str = "INFO",
    ):
        self._events_path  = os.path.join(LOG_DIR, events_file)
        self._denied_path  = os.path.join(LOG_DIR, denied_file)
        self._security_path = os.path.join(LOG_DIR, security_log)
        self._console_output = console_output
        self._min_level = min_console_level
        self._buffer: list = []

        # Python stdlib logger for security.log
        self._file_logger = logging.getLogger("iomt_security")
        self._file_logger.setLevel(logging.DEBUG)
        if not self._file_logger.handlers:
            fh = logging.FileHandler(self._security_path)
            fh.setFormatter(logging.Formatter(
                "%(asctime)s  %(levelname)-8s  %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S UTC"
            ))
            self._file_logger.addHandler(fh)

    # ── Public API ────────────────────────────────────────────────────────────

    def log_allow(self, packet, src_ip: str, reason: str):
        """Log an allowed packet."""
        event = self._build_event(
            event_type="PACKET_ALLOWED",
            packet=packet,
            src_ip=src_ip,
            decision="ALLOW",
            reason=reason,
            severity="INFO",
            threat_level="NONE",
        )
        self._write(event)

    def log_deny(self, packet, src_ip: str, reason: str,
                 threat_level: str = "HIGH"):
        """Log a denied packet."""
        event = self._build_event(
            event_type="PACKET_DENIED",
            packet=packet,
            src_ip=src_ip,
            decision="DENY",
            reason=reason,
            severity=THREAT_SEVERITY.get(threat_level, "ALERT"),
            threat_level=threat_level,
        )
        self._write(event)
        # Also write to denied-only log
        with open(self._denied_path, "a") as f:
            f.write(json.dumps(event) + "\n")

    def log_anomaly(self, device_id: str, description: str,
                    score: float, details: Optional[Dict] = None):
        """Log an anomaly detection event."""
        event = {
            "event_id": self._gen_id(),
            "timestamp": self._now(),
            "event_type": "ANOMALY_DETECTED",
            "device_id": device_id,
            "description": description,
            "anomaly_score": round(score, 4),
            "severity": "ALERT" if score > 0.7 else "WARNING",
            "threat_level": "HIGH" if score > 0.7 else "MEDIUM",
            "details": details or {},
        }
        self._write(event)

    def log_device_quarantined(self, device_id: str, reason: str):
        """Log a device quarantine event."""
        event = {
            "event_id": self._gen_id(),
            "timestamp": self._now(),
            "event_type": "DEVICE_QUARANTINED",
            "device_id": device_id,
            "reason": reason,
            "severity": "CRITICAL",
            "threat_level": "CRITICAL",
            "action": "QUARANTINE",
        }
        self._write(event)
        self._file_logger.critical(
            f"DEVICE QUARANTINED | device_id={device_id} | reason={reason}"
        )

    def log_policy_violation(self, device_id: str, policy_id: str,
                              violation: str, details: Optional[Dict] = None):
        """Log a policy violation."""
        event = {
            "event_id": self._gen_id(),
            "timestamp": self._now(),
            "event_type": "POLICY_VIOLATION",
            "device_id": device_id,
            "policy_id": policy_id,
            "violation": violation,
            "severity": "ALERT",
            "threat_level": "HIGH",
            "details": details or {},
        }
        self._write(event)

    def log_auth_event(self, user_id: str, device_id: str,
                       success: bool, method: str):
        """Log an authentication event."""
        event = {
            "event_id": self._gen_id(),
            "timestamp": self._now(),
            "event_type": "AUTH_SUCCESS" if success else "AUTH_FAILURE",
            "user_id": user_id,
            "device_id": device_id,
            "auth_method": method,
            "severity": "INFO" if success else "WARNING",
            "threat_level": "NONE" if success else "MEDIUM",
        }
        self._write(event)

    def flush(self):
        """Write all buffered events to disk."""
        with open(self._events_path, "a") as f:
            for event in self._buffer:
                f.write(json.dumps(event) + "\n")
        self._buffer.clear()

    def generate_sample_logs(self, count: int = 50):
        """
        Generate a sample log file for demonstration / testing.
        Useful for seeding the anomaly detector.
        """
        import random

        device_ids = ["IP-001", "IP-002", "PM-001", "PM-002", "IS-001", "AW-001"]
        event_types = [
            ("PACKET_ALLOWED", "INFO",     "NONE"),
            ("PACKET_ALLOWED", "INFO",     "NONE"),
            ("PACKET_ALLOWED", "INFO",     "NONE"),
            ("PACKET_DENIED",  "ALERT",    "HIGH"),
            ("ANOMALY_DETECTED","WARNING", "MEDIUM"),
            ("POLICY_VIOLATION","ALERT",   "HIGH"),
            ("DEVICE_QUARANTINED","CRITICAL","CRITICAL"),
        ]

        print(f"Generating {count} sample log entries...")
        for i in range(count):
            device_id = random.choice(device_ids)
            evt_type, severity, threat = random.choice(event_types)
            event = {
                "event_id": f"SAMPLE-{i:04d}",
                "timestamp": self._now(),
                "event_type": evt_type,
                "device_id": device_id,
                "severity": severity,
                "threat_level": threat,
                "reason": f"SAMPLE_LOG_ENTRY_{i}",
            }
            with open(self._events_path, "a") as f:
                f.write(json.dumps(event) + "\n")

        print(f"Sample logs written to {self._events_path}")

    # ── Private Helpers ───────────────────────────────────────────────────────

    def _build_event(
        self,
        event_type: str,
        packet,
        src_ip: str,
        decision: str,
        reason: str,
        severity: str,
        threat_level: str,
    ) -> Dict[str, Any]:
        return {
            "event_id":    self._gen_id(),
            "timestamp":   self._now(),
            "event_type":  event_type,
            "decision":    decision,
            "severity":    severity,
            "threat_level": threat_level,
            "reason":      reason,
            "network": {
                "src_device_id": packet.src_device_id,
                "src_ip":        src_ip,
                "dst_ip":        packet.dst_ip,
                "dst_port":      packet.dst_port,
                "protocol":      packet.protocol,
                "payload_type":  packet.payload_type,
                "payload_size":  packet.payload_size,
                "flags":         packet.flags,
                "packet_id":     packet.packet_id,
            },
        }

    def _write(self, event: Dict):
        """Buffer event + optionally print to console."""
        self._buffer.append(event)
        if len(self._buffer) >= 20:
            self.flush()

        # Console output
        if self._console_output:
            self._print_event(event)

        # Python logger (for security.log file)
        level = event.get("severity", "INFO")
        msg = (
            f"{event['event_type']:<22} | "
            f"src={event.get('network', {}).get('src_device_id', event.get('device_id', 'N/A')):<10} | "
            f"dst={event.get('network', {}).get('dst_ip', 'N/A'):<15} | "
            f"reason={event.get('reason', 'N/A')}"
        )
        getattr(self._file_logger, level.lower(), self._file_logger.info)(msg)

    def _print_event(self, event: Dict):
        """Print formatted event to stdout."""
        severity = event.get("severity", "INFO")
        color = SEVERITY_COLORS.get(severity, RESET)

        # Only show alerts and above on console (reduce noise)
        if severity in ("INFO", "DEBUG"):
            return

        ts = event["timestamp"][11:19]  # HH:MM:SS
        evt = event["event_type"]
        device = (event.get("network", {}).get("src_device_id") or
                  event.get("device_id", "N/A"))
        reason = event.get("reason", "")[:60]

        print(f"  {DIM}[{ts}]{RESET} {color}{BOLD}[{severity}]{RESET} "
              f"{evt} | {device} | {reason}")

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _gen_id() -> str:
        import random
        return f"EVT-{int(datetime.now(timezone.utc).timestamp() * 1000) % 10000000:07d}"


# ── Standalone Usage ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    logger = IoMTLogger()
    logger.generate_sample_logs(100)
    logger.log_device_quarantined("IP-001", "COMPROMISE_DETECTED")
    logger.log_anomaly("PM-001", "Unusual data volume spike", 0.87,
                       details={"bytes_last_5min": 15000000, "baseline": 512000})
    logger.flush()
    print(f"Logs written to {LOG_DIR}/")
