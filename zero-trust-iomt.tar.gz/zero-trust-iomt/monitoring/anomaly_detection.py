"""
anomaly_detection.py — IoMT Behavioral Anomaly Detection Engine
================================================================
Implements statistical and rule-based anomaly detection for IoMT
network traffic patterns.

Detection Methods:
  1. Z-Score Statistical Analysis       — Detect volumetric anomalies
  2. Inter-VLAN Communication Detection — Detect micro-segmentation violations
  3. Port Scan Detection                — Detect reconnaissance activity
  4. Time-Based Baseline Deviation      — Detect off-hours activity
  5. Trust Score Degradation            — Detect gradual compromise
  6. Payload Size Anomaly               — Detect data exfiltration
  7. Connection Frequency Analysis      — Detect C2 beacon patterns

Usage:
    python anomaly_detection.py --mode analyze --logfile logs/iomt_events.jsonl
    python anomaly_detection.py --mode demo
"""

import json
import os
import sys
import math
import argparse
import time
from collections import defaultdict, deque
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple, Any

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")

# ── ANSI ───────────────────────────────────────────────────────────────────────
RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
RESET  = "\033[0m"


# ── Anomaly Alert Dataclass ────────────────────────────────────────────────────

class AnomalyAlert:
    def __init__(
        self,
        alert_type: str,
        device_id: str,
        description: str,
        score: float,          # 0.0 → 1.0
        severity: str,         # LOW | MEDIUM | HIGH | CRITICAL
        evidence: Dict,
        recommended_action: str,
    ):
        self.alert_type = alert_type
        self.device_id = device_id
        self.description = description
        self.score = score
        self.severity = severity
        self.evidence = evidence
        self.recommended_action = recommended_action
        self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp,
            "alert_type": self.alert_type,
            "device_id": self.device_id,
            "description": self.description,
            "anomaly_score": round(self.score, 4),
            "severity": self.severity,
            "evidence": self.evidence,
            "recommended_action": self.recommended_action,
        }

    def __repr__(self):
        return (f"[{self.severity}] {self.alert_type} | {self.device_id} | "
                f"score={self.score:.3f} | {self.description}")


# ── Statistical Helpers ────────────────────────────────────────────────────────

def mean(values: List[float]) -> float:
    return sum(values) / len(values) if values else 0.0

def stddev(values: List[float]) -> float:
    if len(values) < 2:
        return 0.0
    m = mean(values)
    variance = sum((x - m) ** 2 for x in values) / (len(values) - 1)
    return math.sqrt(variance)

def z_score(value: float, values: List[float]) -> float:
    """Compute z-score of value within a distribution."""
    if len(values) < 2:
        return 0.0
    m = mean(values)
    s = stddev(values)
    if s == 0:
        return 0.0
    return abs((value - m) / s)


# ── Anomaly Detection Engine ──────────────────────────────────────────────────

class IoMTAnomalyDetector:
    """
    Multi-method behavioral anomaly detector for IoMT devices.
    Maintains rolling baselines per device and fires alerts when
    behavior deviates significantly from normal patterns.
    """

    # Baseline window: number of observations to maintain per device
    BASELINE_WINDOW = 100

    # Z-score threshold for volumetric anomalies
    Z_SCORE_THRESHOLD = 3.0

    # Maximum connections per minute before flagging
    MAX_CONNECTIONS_PER_MIN = 60

    # Maximum unique destination IPs before port-scan alert
    MAX_UNIQUE_DSTS_PER_MIN = 5

    # Payload size thresholds (bytes)
    NORMAL_MAX_PAYLOAD = 65536       # 64 KB
    EXFIL_PAYLOAD_THRESHOLD = 1048576  # 1 MB

    def __init__(self):
        # Per-device rolling metrics
        self._payload_history:   Dict[str, deque] = defaultdict(lambda: deque(maxlen=self.BASELINE_WINDOW))
        self._conn_timestamps:   Dict[str, deque] = defaultdict(lambda: deque(maxlen=self.BASELINE_WINDOW))
        self._dst_per_minute:    Dict[str, set]   = defaultdict(set)
        self._denied_count:      Dict[str, int]   = defaultdict(int)
        self._port_attempts:     Dict[str, set]   = defaultdict(set)
        self._trust_history:     Dict[str, deque] = defaultdict(lambda: deque(maxlen=20))
        self._alerts:            List[AnomalyAlert] = []
        self._window_start:      Dict[str, datetime] = {}

    # ── Main Ingest API ───────────────────────────────────────────────────────

    def ingest_event(self, event: Dict) -> Optional[AnomalyAlert]:
        """
        Process a single log event and return an anomaly alert if detected,
        or None if behavior is normal.
        """
        event_type = event.get("event_type", "")
        network    = event.get("network", {})
        device_id  = network.get("src_device_id") or event.get("device_id", "UNKNOWN")
        timestamp  = event.get("timestamp", self._now())

        # Track denial counts
        if event_type == "PACKET_DENIED":
            self._denied_count[device_id] += 1
            alert = self._check_denial_spike(device_id)
            if alert:
                return alert

        if event_type in ("PACKET_ALLOWED", "PACKET_DENIED"):
            # Payload size tracking
            payload_size = network.get("payload_size", 0)
            self._payload_history[device_id].append(payload_size)

            # Connection frequency
            self._conn_timestamps[device_id].append(datetime.now(timezone.utc))

            # Destination tracking (for port scan detection)
            dst_ip   = network.get("dst_ip", "")
            dst_port = network.get("dst_port", 0)
            self._dst_per_minute[device_id].add(dst_ip)
            self._port_attempts[device_id].add(dst_port)

            # Run detectors
            for detector in [
                self._detect_payload_anomaly,
                self._detect_connection_flood,
                self._detect_port_scan,
                self._detect_exfiltration,
                self._detect_off_hours_activity,
            ]:
                alert = detector(device_id, event)
                if alert:
                    self._alerts.append(alert)
                    return alert

        return None

    # ── Detection Methods ─────────────────────────────────────────────────────

    def _detect_payload_anomaly(self, device_id: str, event: Dict) -> Optional[AnomalyAlert]:
        """Z-score based payload size anomaly detection."""
        history = list(self._payload_history[device_id])
        if len(history) < 10:
            return None

        current_size = event.get("network", {}).get("payload_size", 0)
        z = z_score(current_size, history[:-1])

        if z > self.Z_SCORE_THRESHOLD and current_size > 1024:
            score = min(1.0, z / 10.0)
            return AnomalyAlert(
                alert_type="PAYLOAD_SIZE_ANOMALY",
                device_id=device_id,
                description=f"Payload size {current_size}B is {z:.1f}σ above baseline",
                score=score,
                severity="HIGH" if score > 0.6 else "MEDIUM",
                evidence={
                    "current_payload_bytes": current_size,
                    "baseline_mean_bytes": round(mean(history), 0),
                    "baseline_stddev": round(stddev(history), 0),
                    "z_score": round(z, 2),
                },
                recommended_action="Inspect packet contents and validate device state",
            )
        return None

    def _detect_connection_flood(self, device_id: str, event: Dict) -> Optional[AnomalyAlert]:
        """Detect abnormally high connection rates (DoS / beaconing)."""
        now = datetime.now(timezone.utc)
        one_min_ago = now - timedelta(minutes=1)

        recent = [t for t in self._conn_timestamps[device_id] if t > one_min_ago]
        conn_rate = len(recent)

        if conn_rate > self.MAX_CONNECTIONS_PER_MIN:
            score = min(1.0, conn_rate / (self.MAX_CONNECTIONS_PER_MIN * 3))
            return AnomalyAlert(
                alert_type="CONNECTION_FLOOD",
                device_id=device_id,
                description=f"Connection rate {conn_rate}/min exceeds threshold {self.MAX_CONNECTIONS_PER_MIN}/min",
                score=score,
                severity="CRITICAL" if score > 0.8 else "HIGH",
                evidence={
                    "connections_last_minute": conn_rate,
                    "threshold": self.MAX_CONNECTIONS_PER_MIN,
                },
                recommended_action="Rate-limit device and investigate DoS/beaconing activity",
            )
        return None

    def _detect_port_scan(self, device_id: str, event: Dict) -> Optional[AnomalyAlert]:
        """Detect reconnaissance / port scanning behavior."""
        unique_dsts  = len(self._dst_per_minute[device_id])
        unique_ports = len(self._port_attempts[device_id])

        if unique_dsts > self.MAX_UNIQUE_DSTS_PER_MIN:
            score = min(1.0, unique_dsts / (self.MAX_UNIQUE_DSTS_PER_MIN * 4))
            return AnomalyAlert(
                alert_type="PORT_SCAN_DETECTED",
                device_id=device_id,
                description=f"Device contacted {unique_dsts} unique IPs (threshold: {self.MAX_UNIQUE_DSTS_PER_MIN})",
                score=score,
                severity="HIGH",
                evidence={
                    "unique_destinations": unique_dsts,
                    "unique_ports_attempted": unique_ports,
                    "threshold": self.MAX_UNIQUE_DSTS_PER_MIN,
                    "destinations": list(self._dst_per_minute[device_id]),
                },
                recommended_action="Quarantine device — possible recon / lateral movement",
            )
        return None

    def _detect_exfiltration(self, device_id: str, event: Dict) -> Optional[AnomalyAlert]:
        """Detect potential data exfiltration based on cumulative payload volume."""
        history = list(self._payload_history[device_id])
        total_volume = sum(history[-20:])  # Last 20 packets

        if total_volume > self.EXFIL_PAYLOAD_THRESHOLD:
            score = min(1.0, total_volume / (self.EXFIL_PAYLOAD_THRESHOLD * 5))
            return AnomalyAlert(
                alert_type="DATA_EXFILTRATION_SUSPECTED",
                device_id=device_id,
                description=f"Cumulative outbound data {total_volume // 1024}KB exceeds exfil threshold",
                score=score,
                severity="CRITICAL",
                evidence={
                    "total_bytes_last_20_packets": total_volume,
                    "threshold_bytes": self.EXFIL_PAYLOAD_THRESHOLD,
                    "mb_transferred": round(total_volume / 1048576, 2),
                },
                recommended_action="IMMEDIATE: Block device egress, preserve forensic evidence",
            )
        return None

    def _detect_off_hours_activity(self, device_id: str, event: Dict) -> Optional[AnomalyAlert]:
        """
        Flag non-gateway medical devices active between 02:00–05:00 UTC.
        Most medical devices should be dormant or have low traffic at this time.
        """
        now_hour = datetime.now(timezone.utc).hour
        payload_type = event.get("network", {}).get("payload_type", "")

        # Skip if normal clinical types
        normal_types = {"hl7v2", "fhir", "dicom", "hl7v2-telemetry",
                        "fhir-r4-vitals", "realtime-stream"}
        if any(nt in payload_type for nt in normal_types):
            return None

        if 2 <= now_hour <= 5:
            return AnomalyAlert(
                alert_type="OFF_HOURS_UNUSUAL_ACTIVITY",
                device_id=device_id,
                description=f"Unusual activity from medical device at {now_hour:02d}:xx UTC (off-hours window)",
                score=0.55,
                severity="MEDIUM",
                evidence={
                    "utc_hour": now_hour,
                    "payload_type": payload_type,
                    "off_hours_window": "02:00–05:00 UTC",
                },
                recommended_action="Verify legitimacy of device activity during off-hours",
            )
        return None

    def _check_denial_spike(self, device_id: str) -> Optional[AnomalyAlert]:
        """Alert when a device accumulates too many policy denials."""
        count = self._denied_count[device_id]
        thresholds = [(50, "CRITICAL", 0.95), (20, "HIGH", 0.75), (10, "MEDIUM", 0.5)]

        for threshold, severity, score in thresholds:
            if count == threshold:  # Fire exactly at threshold, not every event
                return AnomalyAlert(
                    alert_type="POLICY_DENIAL_SPIKE",
                    device_id=device_id,
                    description=f"Device has accumulated {count} policy denials",
                    score=score,
                    severity=severity,
                    evidence={
                        "denial_count": count,
                        "threshold": threshold,
                    },
                    recommended_action=(
                        "Quarantine device immediately" if severity == "CRITICAL"
                        else "Investigate device behavior and review policies"
                    ),
                )
        return None

    # ── Bulk Analysis ─────────────────────────────────────────────────────────

    def analyze_log_file(self, log_path: str) -> List[AnomalyAlert]:
        """Read a JSONL log file and run anomaly detection on all events."""
        alerts = []
        processed = 0

        if not os.path.exists(log_path):
            print(f"  {YELLOW}[WARNING] Log file not found: {log_path}{RESET}")
            return alerts

        with open(log_path, "r") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                    alert = self.ingest_event(event)
                    if alert:
                        alerts.append(alert)
                    processed += 1
                except json.JSONDecodeError:
                    continue

        print(f"  Processed {processed} log events, detected {len(alerts)} anomalies")
        return alerts

    # ── Risk Dashboard ────────────────────────────────────────────────────────

    def print_risk_dashboard(self):
        """Print a formatted risk dashboard based on collected alerts."""
        print(f"\n{BOLD}{CYAN}{'═' * 65}{RESET}")
        print(f"{BOLD}{CYAN}  IoMT ANOMALY DETECTION — RISK DASHBOARD{RESET}")
        print(f"{BOLD}{CYAN}{'═' * 65}{RESET}\n")

        if not self._alerts:
            print(f"  {GREEN}✓ No anomalies detected in analyzed traffic.{RESET}\n")
            return

        # Group by device
        by_device: Dict[str, List[AnomalyAlert]] = defaultdict(list)
        for alert in self._alerts:
            by_device[alert.device_id].append(alert)

        for device_id, device_alerts in sorted(by_device.items()):
            max_score = max(a.score for a in device_alerts)
            max_sev   = max(device_alerts, key=lambda a: a.score).severity
            color = RED if max_sev in ("CRITICAL", "HIGH") else YELLOW

            print(f"  {color}{BOLD}[{device_id}]{RESET} — {len(device_alerts)} alerts, "
                  f"max risk score: {color}{max_score:.3f}{RESET}")
            for alert in sorted(device_alerts, key=lambda a: a.score, reverse=True):
                sev_color = RED if alert.severity in ("CRITICAL", "HIGH") else YELLOW
                print(f"    {sev_color}▸{RESET} [{alert.severity}] {alert.alert_type}: "
                      f"{alert.description[:55]}")
                print(f"      Action: {DIM}{alert.recommended_action}{RESET}")
            print()

        # Summary
        critical = sum(1 for a in self._alerts if a.severity == "CRITICAL")
        high     = sum(1 for a in self._alerts if a.severity == "HIGH")
        medium   = sum(1 for a in self._alerts if a.severity == "MEDIUM")
        print(f"  {'─' * 50}")
        print(f"  Total Alerts: {len(self._alerts)} | "
              f"{RED}Critical: {critical}{RESET} | "
              f"{YELLOW}High: {high}{RESET} | "
              f"Medium: {medium}")
        print(f"{BOLD}{CYAN}{'═' * 65}{RESET}\n")

    def export_alerts(self, path: str = "logs/anomaly_alerts.json"):
        """Export all alerts to JSON."""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            json.dump(
                {
                    "generated_at": datetime.now(timezone.utc).isoformat(),
                    "total_alerts": len(self._alerts),
                    "alerts": [a.to_dict() for a in self._alerts],
                },
                f, indent=2,
            )

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    # ── Demo Mode ─────────────────────────────────────────────────────────────

    def run_demo(self):
        """Inject synthetic events to demonstrate anomaly detection capabilities."""
        print(f"\n{BOLD}{CYAN}  ANOMALY DETECTION ENGINE — DEMO MODE{RESET}\n")

        demo_events = [
            # Normal baseline events
            *[{
                "event_type": "PACKET_ALLOWED",
                "network": {
                    "src_device_id": "PM-001",
                    "dst_ip": "10.0.99.20",
                    "dst_port": 443,
                    "payload_size": 512,
                    "payload_type": "fhir-r4-vitals",
                },
            } for _ in range(15)],

            # Payload spike (exfiltration)
            {
                "event_type": "PACKET_ALLOWED",
                "network": {
                    "src_device_id": "PM-001",
                    "dst_ip": "10.0.99.20",
                    "dst_port": 443,
                    "payload_size": 5242880,  # 5 MB — anomalous
                    "payload_type": "unknown-binary",
                },
            },

            # Denial spike on IP-001
            *[{
                "event_type": "PACKET_DENIED",
                "network": {
                    "src_device_id": "IP-001",
                    "dst_ip": f"10.0.{i}.1",
                    "dst_port": 3389,
                    "payload_size": 64,
                    "payload_type": "tcp-syn-probe",
                },
            } for i in range(10, 30)],  # 20 denials → triggers MEDIUM alert
        ]

        print(f"  Injecting {len(demo_events)} synthetic events...\n")
        for event in demo_events:
            alert = self.ingest_event(event)
            if alert:
                sev_color = RED if alert.severity in ("CRITICAL", "HIGH") else YELLOW
                print(f"  {sev_color}{BOLD}[ANOMALY DETECTED]{RESET}")
                print(f"  Type     : {alert.alert_type}")
                print(f"  Device   : {alert.device_id}")
                print(f"  Score    : {alert.score:.3f}")
                print(f"  Severity : {sev_color}{alert.severity}{RESET}")
                print(f"  Detail   : {alert.description}")
                print(f"  Action   : {DIM}{alert.recommended_action}{RESET}")
                print(f"  {'─' * 55}\n")
            time.sleep(0.02)

        self.print_risk_dashboard()
        self.export_alerts(os.path.join(LOG_DIR, "anomaly_alerts.json"))


# ── Entry Point ────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="IoMT Anomaly Detection Engine")
    parser.add_argument("--mode", choices=["analyze", "demo"], default="demo")
    parser.add_argument("--logfile", default=os.path.join(LOG_DIR, "iomt_events.jsonl"))
    args = parser.parse_args()

    detector = IoMTAnomalyDetector()

    if args.mode == "demo":
        detector.run_demo()
    elif args.mode == "analyze":
        print(f"\n  Analyzing log file: {args.logfile}")
        alerts = detector.analyze_log_file(args.logfile)
        detector.print_risk_dashboard()
        detector.export_alerts()


if __name__ == "__main__":
    main()
