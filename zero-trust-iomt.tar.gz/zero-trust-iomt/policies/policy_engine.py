"""
policy_engine.py — Zero Trust Policy Enforcement Engine
=========================================================
Implements a policy decision point (PDP) that evaluates every network
communication request against Zero Trust principles:

  1. Never trust, always verify
  2. Assume breach
  3. Least-privilege access

Policy evaluation pipeline:
  Step 1 — Device Identity Verification  (cert thumbprint / MAC)
  Step 2 — Authorization Status Check    (is device in registry?)
  Step 3 — Trust Score Threshold         (continuous authentication)
  Step 4 — Source IP / Role Check        (RBAC)
  Step 5 — Destination Allow-list        (explicit path authorization)
  Step 6 — Port / Protocol Allow-list    (least privilege)
  Step 7 — Payload Anomaly Check         (detect exploit signatures)
  Step 8 — Time & Context Rules          (working hours, etc.)
  Step 9 — Cross-Segment Restriction     (micro-segmentation)

All decisions are logged with full context.
"""

import re
import json
import time
from typing import Dict, Any, Optional
from datetime import datetime, timezone

# ── Constants ─────────────────────────────────────────────────────────────────

# Known malicious payload patterns (simplified IDS signatures)
MALICIOUS_PAYLOAD_PATTERNS = [
    r"exploit",
    r"exfil",
    r"c2-beacon",
    r"ransomware",
    r"brute.?force",
    r"syn.?flood",
    r"icmp.?flood",
    r"implant",
    r"backdoor",
    r"shellcode",
    r"overflow",
    r"injection",
    r"probe",
    r"scan",
]

# Minimum trust score required to communicate
TRUST_SCORE_THRESHOLD = 0.5

# High-risk ports that require extra scrutiny
HIGH_RISK_PORTS = {23, 3389, 22, 445, 137, 138, 139, 1433, 3306, 5432}

# Ports that are never permitted cross-VLAN (even in normal operation)
ALWAYS_BLOCKED_PORTS = {23, 21, 69, 161, 162}  # Telnet, FTP, TFTP, SNMP

# Known payload types that indicate malicious intent
MALICIOUS_PAYLOAD_TYPES = {
    "exploit", "exfil", "c2", "probe", "flood", "brute",
    "implant", "backdoor", "ransomware", "shellcode",
}


class PolicyDecision:
    """Encapsulates the result of a policy evaluation."""

    def __init__(
        self,
        allowed: bool,
        reason: str,
        policy_id: str,
        threat_level: str = "NONE",
        details: Optional[Dict] = None,
    ):
        self.allowed = allowed
        self.reason = reason
        self.policy_id = policy_id
        self.threat_level = threat_level          # NONE | LOW | MEDIUM | HIGH | CRITICAL
        self.details = details or {}
        self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict:
        return {
            "allowed": self.allowed,
            "reason": self.reason,
            "policy_id": self.policy_id,
            "threat_level": self.threat_level,
            "details": self.details,
            "timestamp": self.timestamp,
        }

    def __repr__(self):
        status = "ALLOW" if self.allowed else "DENY"
        return f"PolicyDecision({status}, policy={self.policy_id}, reason={self.reason})"


class ZeroTrustPolicyEngine:
    """
    Policy Decision Point (PDP) — evaluates every packet against
    the Zero Trust policy set.
    """

    def __init__(self, topology):
        self.topology = topology
        self._compiled_patterns = [
            re.compile(p, re.IGNORECASE) for p in MALICIOUS_PAYLOAD_PATTERNS
        ]

    # ── Main Evaluation Entry Point ───────────────────────────────────────────

    def evaluate(self, packet) -> Dict[str, Any]:
        """
        Evaluate a Packet against all Zero Trust policies.
        Returns a decision dictionary.
        """
        ctx = self._build_context(packet)

        # Run policies in priority order (fail-fast on DENY)
        checks = [
            self._check_p01_device_known,
            self._check_p02_device_authorized,
            self._check_p03_device_trust_score,
            self._check_p04_cert_validity,
            self._check_p05_device_compromised,
            self._check_p06_port_allowlist,
            self._check_p07_destination_allowlist,
            self._check_p08_cross_segment_restriction,
            self._check_p09_payload_signature,
            self._check_p10_high_risk_port_elevation,
        ]

        for check_fn in checks:
            decision = check_fn(ctx)
            if not decision.allowed:
                return decision.to_dict()

        # All checks passed → ALLOW
        return PolicyDecision(
            allowed=True,
            reason="ALL_POLICIES_PASSED",
            policy_id="P-ALLOW",
            threat_level="NONE",
            details=ctx,
        ).to_dict()

    # ── Context Builder ───────────────────────────────────────────────────────

    def _build_context(self, packet) -> Dict:
        src = self.topology.get_device(packet.src_device_id)
        return {
            "packet": packet.to_dict(),
            "src_device": src.to_dict() if src else None,
            "src_known": src is not None,
            "src_ip": src.ip if src else "UNKNOWN",
            "dst_ip": packet.dst_ip,
            "dst_port": packet.dst_port,
            "payload_type": packet.payload_type,
            "flags": packet.flags,
        }

    # ── Individual Policy Checks ──────────────────────────────────────────────

    def _check_p01_device_known(self, ctx: Dict) -> PolicyDecision:
        """P01: Device must be in the authorised registry."""
        if not ctx["src_known"]:
            return PolicyDecision(
                allowed=False,
                reason="UNKNOWN_DEVICE_NOT_IN_REGISTRY",
                policy_id="P01",
                threat_level="HIGH",
                details={"src_device_id": ctx["packet"]["src_device_id"]},
            )
        return PolicyDecision(allowed=True, reason="P01_PASS", policy_id="P01")

    def _check_p02_device_authorized(self, ctx: Dict) -> PolicyDecision:
        """P02: Device must have authorized flag set."""
        src = ctx["src_device"]
        if src and not src["authorized"]:
            return PolicyDecision(
                allowed=False,
                reason="DEVICE_AUTHORIZATION_REVOKED",
                policy_id="P02",
                threat_level="CRITICAL",
                details={"device_id": src["device_id"], "name": src["name"]},
            )
        return PolicyDecision(allowed=True, reason="P02_PASS", policy_id="P02")

    def _check_p03_device_trust_score(self, ctx: Dict) -> PolicyDecision:
        """P03: Device trust score must exceed minimum threshold."""
        src = ctx["src_device"]
        if src and src["trust_score"] < TRUST_SCORE_THRESHOLD:
            return PolicyDecision(
                allowed=False,
                reason=f"TRUST_SCORE_BELOW_THRESHOLD_{TRUST_SCORE_THRESHOLD}",
                policy_id="P03",
                threat_level="HIGH",
                details={
                    "device_id": src["device_id"],
                    "trust_score": src["trust_score"],
                    "threshold": TRUST_SCORE_THRESHOLD,
                },
            )
        return PolicyDecision(allowed=True, reason="P03_PASS", policy_id="P03")

    def _check_p04_cert_validity(self, ctx: Dict) -> PolicyDecision:
        """P04: Device certificate thumbprint must not be INVALID."""
        src = ctx["src_device"]
        if src:
            cert = src.get("cert_thumbprint", "")
            if not cert or "INVALID" in cert.upper() or len(cert) < 20:
                return PolicyDecision(
                    allowed=False,
                    reason="INVALID_OR_MISSING_DEVICE_CERTIFICATE",
                    policy_id="P04",
                    threat_level="CRITICAL",
                    details={"device_id": src["device_id"], "cert": cert},
                )
        return PolicyDecision(allowed=True, reason="P04_PASS", policy_id="P04")

    def _check_p05_device_compromised(self, ctx: Dict) -> PolicyDecision:
        """P05: Compromised devices are immediately quarantined."""
        src = ctx["src_device"]
        if src and src.get("compromised", False):
            return PolicyDecision(
                allowed=False,
                reason="DEVICE_QUARANTINED_COMPROMISE_DETECTED",
                policy_id="P05",
                threat_level="CRITICAL",
                details={
                    "device_id": src["device_id"],
                    "name": src["name"],
                    "action": "QUARANTINE",
                },
            )
        return PolicyDecision(allowed=True, reason="P05_PASS", policy_id="P05")

    def _check_p06_port_allowlist(self, ctx: Dict) -> PolicyDecision:
        """P06: Destination port must be in device's allowed port list."""
        src = ctx["src_device"]
        dst_port = ctx["dst_port"]

        # Always-blocked ports (telnet, FTP, etc.)
        if dst_port in ALWAYS_BLOCKED_PORTS:
            return PolicyDecision(
                allowed=False,
                reason=f"PORT_{dst_port}_GLOBALLY_PROHIBITED",
                policy_id="P06",
                threat_level="HIGH",
                details={"port": dst_port, "rule": "ALWAYS_BLOCKED"},
            )

        if src and dst_port not in src["allowed_ports"]:
            return PolicyDecision(
                allowed=False,
                reason=f"PORT_{dst_port}_NOT_IN_DEVICE_ALLOWLIST",
                policy_id="P06",
                threat_level="MEDIUM",
                details={
                    "device_id": src["device_id"],
                    "requested_port": dst_port,
                    "allowed_ports": src["allowed_ports"],
                },
            )
        return PolicyDecision(allowed=True, reason="P06_PASS", policy_id="P06")

    def _check_p07_destination_allowlist(self, ctx: Dict) -> PolicyDecision:
        """P07: Destination IP must be in device's explicit allow-list."""
        src = ctx["src_device"]
        dst_ip = ctx["dst_ip"]

        if src:
            allowed_dests = src["allowed_destinations"]
            # Check exact match or "0.0.0.0/0" wildcard (only for gateway)
            if "0.0.0.0/0" in allowed_dests:
                return PolicyDecision(allowed=True, reason="P07_PASS_GATEWAY",
                                      policy_id="P07")
            if dst_ip not in allowed_dests:
                return PolicyDecision(
                    allowed=False,
                    reason=f"DESTINATION_{dst_ip}_NOT_IN_DEVICE_ALLOWLIST",
                    policy_id="P07",
                    threat_level="HIGH",
                    details={
                        "device_id": src["device_id"],
                        "requested_dst": dst_ip,
                        "allowed_destinations": allowed_dests,
                    },
                )
        return PolicyDecision(allowed=True, reason="P07_PASS", policy_id="P07")

    def _check_p08_cross_segment_restriction(self, ctx: Dict) -> PolicyDecision:
        """P08: Cross-VLAN communication is restricted to approved paths only."""
        src = ctx["src_device"]
        if not src:
            return PolicyDecision(allowed=True, reason="P08_SKIP_NO_SRC",
                                  policy_id="P08")

        src_vlan = src["vlan"]

        # Determine dst VLAN from IP
        dst_ip = ctx["dst_ip"]
        dst_vlan = self._ip_to_vlan(dst_ip)

        if dst_vlan is None:
            # External IP (e.g., C2 server) — block all egress from medical devices
            if src["role"] not in ("zta_gateway", "admin_workstation"):
                return PolicyDecision(
                    allowed=False,
                    reason="MEDICAL_DEVICE_EXTERNAL_EGRESS_PROHIBITED",
                    policy_id="P08",
                    threat_level="CRITICAL",
                    details={
                        "device_id": src["device_id"],
                        "dst_ip": dst_ip,
                        "rule": "NO_EXTERNAL_INTERNET_FROM_MEDICAL_VLANS",
                    },
                )

        # Infusion pumps CANNOT communicate with imaging or admin VLANs directly
        if src["role"] == "infusion_pump" and dst_vlan in (20, 30, 40):
            return PolicyDecision(
                allowed=False,
                reason=f"INFUSION_PUMP_CROSS_SEGMENT_VLAN{dst_vlan}_PROHIBITED",
                policy_id="P08",
                threat_level="HIGH",
                details={
                    "src_vlan": src_vlan,
                    "dst_vlan": dst_vlan,
                    "rule": "INFUSION_PUMP_ISOLATION",
                },
            )

        return PolicyDecision(allowed=True, reason="P08_PASS", policy_id="P08")

    def _check_p09_payload_signature(self, ctx: Dict) -> PolicyDecision:
        """P09: Payload type must not match known attack signatures."""
        payload_type = ctx.get("payload_type", "").lower()

        # Check exact malicious type keywords
        for bad_kw in MALICIOUS_PAYLOAD_TYPES:
            if bad_kw in payload_type:
                return PolicyDecision(
                    allowed=False,
                    reason=f"MALICIOUS_PAYLOAD_SIGNATURE_MATCH_{bad_kw.upper()}",
                    policy_id="P09",
                    threat_level="CRITICAL",
                    details={
                        "payload_type": payload_type,
                        "matched_signature": bad_kw,
                    },
                )

        # Check regex patterns
        for pattern in self._compiled_patterns:
            if pattern.search(payload_type):
                return PolicyDecision(
                    allowed=False,
                    reason=f"MALICIOUS_PAYLOAD_PATTERN_MATCH_{pattern.pattern.upper()}",
                    policy_id="P09",
                    threat_level="CRITICAL",
                    details={
                        "payload_type": payload_type,
                        "matched_pattern": pattern.pattern,
                    },
                )

        return PolicyDecision(allowed=True, reason="P09_PASS", policy_id="P09")

    def _check_p10_high_risk_port_elevation(self, ctx: Dict) -> PolicyDecision:
        """P10: High-risk ports require additional role authorization."""
        src = ctx["src_device"]
        dst_port = ctx["dst_port"]

        if dst_port in HIGH_RISK_PORTS:
            if src and src["role"] not in ("admin_workstation", "zta_gateway"):
                return PolicyDecision(
                    allowed=False,
                    reason=f"HIGH_RISK_PORT_{dst_port}_REQUIRES_ELEVATED_ROLE",
                    policy_id="P10",
                    threat_level="HIGH",
                    details={
                        "device_id": src["device_id"],
                        "role": src["role"],
                        "requested_port": dst_port,
                        "required_roles": ["admin_workstation", "zta_gateway"],
                    },
                )
        return PolicyDecision(allowed=True, reason="P10_PASS", policy_id="P10")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _ip_to_vlan(self, ip: str) -> Optional[int]:
        """Map an IP address to its VLAN ID based on subnet."""
        octet_map = {
            "10.0.10.": 10,
            "10.0.20.": 20,
            "10.0.30.": 30,
            "10.0.40.": 40,
            "10.0.99.": 99,
        }
        for prefix, vlan in octet_map.items():
            if ip.startswith(prefix):
                return vlan
        return None  # External / unknown

    def explain_policies(self):
        """Print a human-readable explanation of all policies."""
        policies = [
            ("P01", "Device Registry Check",        "Every device must be registered in the ZTA device store"),
            ("P02", "Authorization Status",         "Device authorization flag must be active (not revoked)"),
            ("P03", "Trust Score Threshold",        f"Device trust score must be ≥ {TRUST_SCORE_THRESHOLD}"),
            ("P04", "Certificate Validation",       "Device must present a valid X.509 certificate thumbprint"),
            ("P05", "Compromise Quarantine",        "Compromised devices are immediately denied all comms"),
            ("P06", "Port Allow-list",              "Only pre-approved destination ports are permitted per device"),
            ("P07", "Destination Allow-list",       "Only pre-approved destination IPs are permitted per device"),
            ("P08", "Cross-Segment Restriction",    "Cross-VLAN communication follows strict micro-segmentation rules"),
            ("P09", "Payload Signature Detection",  "Packets with malicious payload signatures are blocked"),
            ("P10", "High-Risk Port Elevation",     "Privileged ports (RDP, SSH, SMB) require elevated device role"),
        ]
        print("\n  Zero Trust Policy Set:")
        print(f"  {'ID':<5} {'Policy Name':<35} Description")
        print("  " + "─" * 80)
        for pid, name, desc in policies:
            print(f"  {pid:<5} {name:<35} {desc}")
        print()
