# opa_policy.rego — Open Policy Agent Zero Trust Policies for IoMT
# =================================================================
# Implements NIST SP 800-207 Zero Trust Architecture policies for
# Internet of Medical Things (IoMT) devices.
#
# Evaluate with:
#   opa eval -d opa_policy.rego -i input.json "data.iomt.zerotrust.allow"
#   opa eval -d opa_policy.rego -i input.json "data.iomt.zerotrust.deny_reason"
#
# Input schema:
# {
#   "device": {
#     "device_id": "IP-001",
#     "role": "infusion_pump",
#     "authorized": true,
#     "compromised": false,
#     "trust_score": 0.9,
#     "vlan": 10,
#     "allowed_destinations": ["10.0.99.20"],
#     "allowed_ports": [443, 8443],
#     "cert_thumbprint": "SHA256:abc123..."
#   },
#   "request": {
#     "dst_ip": "10.0.99.20",
#     "dst_port": 443,
#     "protocol": "TCP",
#     "payload_type": "hl7v2-telemetry"
#   },
#   "user": {
#     "id": "user-001",
#     "role": "clinician",
#     "mfa_verified": true
#   }
# }

package iomt.zerotrust

import future.keywords.if
import future.keywords.in

# ─────────────────────────────────────────────────────────────────────────────
# TOP-LEVEL DECISION
# ─────────────────────────────────────────────────────────────────────────────

# Default deny — Zero Trust requires explicit allow
default allow := false

# Allow if ALL conditions pass
allow if {
    device_is_known
    device_is_authorized
    device_trust_score_sufficient
    device_not_compromised
    device_cert_valid
    port_is_allowed
    destination_is_allowed
    not cross_segment_violation
    not malicious_payload
    not high_risk_port_unauthorized
}

# ─────────────────────────────────────────────────────────────────────────────
# DEVICE IDENTITY POLICIES
# ─────────────────────────────────────────────────────────────────────────────

# P01: Device must be known (non-null ID with proper format)
device_is_known if {
    input.device.device_id != null
    count(input.device.device_id) > 0
    regex.match(`^[A-Z]{2}-\d{3}$`, input.device.device_id)
}

# P02: Device must be authorized
device_is_authorized if {
    input.device.authorized == true
}

# P03: Trust score above threshold (0.5)
device_trust_score_sufficient if {
    input.device.trust_score >= 0.5
}

# P04: Device certificate must be valid (present and not INVALID)
device_cert_valid if {
    input.device.cert_thumbprint != null
    count(input.device.cert_thumbprint) >= 20
    not contains(lower(input.device.cert_thumbprint), "invalid")
    startswith(input.device.cert_thumbprint, "SHA256:")
}

# P05: Device must not be flagged as compromised
device_not_compromised if {
    input.device.compromised == false
}

# ─────────────────────────────────────────────────────────────────────────────
# ACCESS CONTROL POLICIES
# ─────────────────────────────────────────────────────────────────────────────

# P06: Destination port must be in device allow-list
port_is_allowed if {
    input.request.dst_port in input.device.allowed_ports
}

# P07: Destination IP must be in device allow-list
destination_is_allowed if {
    input.request.dst_ip in input.device.allowed_destinations
}

# Wildcard for gateway role
destination_is_allowed if {
    input.device.role == "zta_gateway"
}

# ─────────────────────────────────────────────────────────────────────────────
# MICRO-SEGMENTATION POLICIES
# ─────────────────────────────────────────────────────────────────────────────

# P08: Infusion pumps cannot communicate with monitors, imaging, or admin VLANs
cross_segment_violation if {
    input.device.role == "infusion_pump"
    dst_vlan := ip_to_vlan(input.request.dst_ip)
    dst_vlan in {20, 30, 40}
}

# P08b: Medical devices cannot communicate with external internet
cross_segment_violation if {
    input.device.role in {"infusion_pump", "patient_monitor", "imaging_system"}
    not internal_ip(input.request.dst_ip)
}

# ─────────────────────────────────────────────────────────────────────────────
# PAYLOAD ANALYSIS POLICIES
# ─────────────────────────────────────────────────────────────────────────────

# P09: Detect malicious payload signatures
malicious_payload if {
    some sig in malicious_signatures
    contains(lower(input.request.payload_type), sig)
}

malicious_signatures := {
    "exploit", "exfil", "c2-beacon", "ransomware", "brute-force",
    "syn-flood", "icmp-flood", "implant", "backdoor", "shellcode",
    "probe", "overflow", "injection", "c2_beacon", "data-exfiltration",
    "port-scan", "rdp-brute", "dicom-exploit",
}

# ─────────────────────────────────────────────────────────────────────────────
# PRIVILEGED PORT POLICIES
# ─────────────────────────────────────────────────────────────────────────────

# P10: High-risk ports require admin or gateway role
high_risk_port_unauthorized if {
    input.request.dst_port in high_risk_ports
    not input.device.role in {"admin_workstation", "zta_gateway"}
}

high_risk_ports := {22, 23, 3389, 445, 137, 138, 139, 1433, 3306, 5432, 21, 69}

# Always-blocked protocols regardless of role
cross_segment_violation if {
    input.request.dst_port in {23, 21, 69}  # Telnet, FTP, TFTP — always prohibited
}

# ─────────────────────────────────────────────────────────────────────────────
# USER / OPERATOR AUTHENTICATION POLICIES
# ─────────────────────────────────────────────────────────────────────────────

# Require MFA for admin role operations
user_auth_valid if {
    input.user.role == "clinician"
    input.user.mfa_verified == true
}

user_auth_valid if {
    input.user.role == "nurse"
    input.user.mfa_verified == true
}

user_auth_valid if {
    input.user.role == "admin"
    input.user.mfa_verified == true
}

# ─────────────────────────────────────────────────────────────────────────────
# DENY REASON HELPERS (for audit logging)
# ─────────────────────────────────────────────────────────────────────────────

deny_reason := reason if {
    not allow
    reason := deny_reasons[_]
}

deny_reasons[r] {
    not device_is_known
    r := "P01: Device not found in registry"
}

deny_reasons[r] {
    not device_is_authorized
    r := "P02: Device authorization revoked"
}

deny_reasons[r] {
    not device_trust_score_sufficient
    r := sprintf("P03: Trust score %.2f below threshold 0.50", [input.device.trust_score])
}

deny_reasons[r] {
    not device_cert_valid
    r := "P04: Invalid or missing device certificate"
}

deny_reasons[r] {
    not device_not_compromised
    r := "P05: Device flagged as compromised — quarantine active"
}

deny_reasons[r] {
    not port_is_allowed
    r := sprintf("P06: Port %d not in device allow-list", [input.request.dst_port])
}

deny_reasons[r] {
    not destination_is_allowed
    r := sprintf("P07: Destination %s not in device allow-list", [input.request.dst_ip])
}

deny_reasons[r] {
    cross_segment_violation
    r := "P08: Cross-segment (VLAN) micro-segmentation violation"
}

deny_reasons[r] {
    malicious_payload
    r := sprintf("P09: Malicious payload signature detected in '%s'", [input.request.payload_type])
}

deny_reasons[r] {
    high_risk_port_unauthorized
    r := sprintf("P10: High-risk port %d requires elevated role", [input.request.dst_port])
}

# ─────────────────────────────────────────────────────────────────────────────
# RISK SCORING
# ─────────────────────────────────────────────────────────────────────────────

# Risk score: 0 (no risk) → 100 (critical)
risk_score := score if {
    base := 0
    comp_score  := device_compromise_score
    trust_score := trust_penalty_score
    payload_score := payload_risk_score
    score := min([100, base + comp_score + trust_score + payload_score])
}

device_compromise_score := 60 if { input.device.compromised == true }
device_compromise_score := 0  if { input.device.compromised == false }

trust_penalty_score := 30 if { input.device.trust_score < 0.3 }
trust_penalty_score := 15 if {
    input.device.trust_score >= 0.3
    input.device.trust_score < 0.6
}
trust_penalty_score := 0  if { input.device.trust_score >= 0.6 }

payload_risk_score := 40 if { malicious_payload }
payload_risk_score := 0  if { not malicious_payload }

# ─────────────────────────────────────────────────────────────────────────────
# HELPER FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

ip_to_vlan(ip) := 10 if { startswith(ip, "10.0.10.") }
ip_to_vlan(ip) := 20 if { startswith(ip, "10.0.20.") }
ip_to_vlan(ip) := 30 if { startswith(ip, "10.0.30.") }
ip_to_vlan(ip) := 40 if { startswith(ip, "10.0.40.") }
ip_to_vlan(ip) := 99 if { startswith(ip, "10.0.99.") }

internal_ip(ip) if { startswith(ip, "10.0.") }
internal_ip(ip) if { startswith(ip, "192.168.") }
internal_ip(ip) if { startswith(ip, "172.16.") }
