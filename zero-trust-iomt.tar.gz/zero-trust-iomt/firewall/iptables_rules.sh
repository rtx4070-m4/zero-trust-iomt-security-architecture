#!/bin/bash
# iptables_rules.sh — IoMT Zero Trust Firewall Configuration
# ===========================================================
# Implements micro-segmentation firewall rules for IoMT VLANs.
#
# Network Layout:
#   VLAN 10 — Infusion Pumps        10.0.10.0/24  (eth0.10)
#   VLAN 20 — Patient Monitors      10.0.20.0/24  (eth0.20)
#   VLAN 30 — Imaging Systems       10.0.30.0/24  (eth0.30)
#   VLAN 40 — Admin/Clinical IT     10.0.40.0/24  (eth0.40)
#   VLAN 99 — Management/ZTA Core   10.0.99.0/24  (eth0.99)
#
# Zero Trust Principles:
#   - Default DENY all (no implicit trust)
#   - Explicit ALLOW only on approved paths
#   - No cross-VLAN communication except through ZTA Gateway
#   - All traffic logged
#
# Usage:
#   sudo bash iptables_rules.sh [apply|flush|status|test]
#
# IMPORTANT: Run as root. Test in a VM/lab environment first.

set -euo pipefail

# ── Configuration ─────────────────────────────────────────────────────────────

VLAN10="10.0.10.0/24"   # Infusion Pumps
VLAN20="10.0.20.0/24"   # Patient Monitors
VLAN30="10.0.30.0/24"   # Imaging Systems
VLAN40="10.0.40.0/24"   # Admin / Clinical IT
VLAN99="10.0.99.0/24"   # Management / ZTA Core

GW_IP="10.0.99.10"      # ZTA Gateway
EHR_IP="10.0.99.20"     # EHR Server

LOG_PREFIX="[ZTA-IOMT]"
LOG_LEVEL=4              # 4 = WARNING

# ── Functions ─────────────────────────────────────────────────────────────────

log_msg() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"; }

check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo "ERROR: This script must be run as root (sudo)."
        exit 1
    fi
}

# ── FLUSH ALL RULES ────────────────────────────────────────────────────────────

flush_rules() {
    log_msg "Flushing all iptables rules..."
    iptables -F
    iptables -X
    iptables -t nat -F
    iptables -t nat -X
    iptables -t mangle -F
    iptables -t mangle -X
    # Reset to ACCEPT (safe default for flush operation)
    iptables -P INPUT   ACCEPT
    iptables -P FORWARD ACCEPT
    iptables -P OUTPUT  ACCEPT
    log_msg "Rules flushed. Chains reset to ACCEPT."
}


# ── APPLY ZERO TRUST RULES ─────────────────────────────────────────────────────

apply_rules() {
    log_msg "Applying Zero Trust IoMT firewall rules..."

    # ── STEP 1: FLUSH EXISTING RULES ─────────────────────────────────────────
    iptables -F
    iptables -X
    iptables -t nat -F

    # ── STEP 2: SET DEFAULT POLICIES — DEFAULT DENY ──────────────────────────
    log_msg "Setting default DENY policies..."
    iptables -P INPUT   DROP
    iptables -P FORWARD DROP
    iptables -P OUTPUT  DROP

    # ── STEP 3: ALLOW ESTABLISHED / RELATED CONNECTIONS ──────────────────────
    # Required for return traffic on allowed connections
    iptables -A INPUT   -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
    iptables -A OUTPUT  -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
    iptables -A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

    # ── STEP 4: ALLOW LOOPBACK ────────────────────────────────────────────────
    iptables -A INPUT  -i lo -j ACCEPT
    iptables -A OUTPUT -o lo -j ACCEPT

    # ── STEP 5: BLOCK GLOBALLY PROHIBITED PROTOCOLS ──────────────────────────
    log_msg "Blocking globally prohibited protocols (Telnet, FTP, TFTP, SNMP)..."

    BLOCKED_PORTS="23 21 69 161 162"
    for PORT in $BLOCKED_PORTS; do
        iptables -A FORWARD -p tcp --dport "$PORT" \
            -m limit --limit 5/min --limit-burst 10 \
            -j LOG --log-prefix "$LOG_PREFIX PROHIBITED-PORT-$PORT " --log-level "$LOG_LEVEL"
        iptables -A FORWARD -p tcp --dport "$PORT" -j DROP
        iptables -A FORWARD -p udp --dport "$PORT" -j DROP
    done

    # ── STEP 6: INFUSION PUMP RULES (VLAN 10) ────────────────────────────────
    log_msg "Configuring Infusion Pump rules (VLAN 10 → EHR only)..."

    # Infusion pumps → EHR server (HTTPS/8443 only)
    iptables -A FORWARD \
        -s "$VLAN10" -d "$EHR_IP" \
        -p tcp -m multiport --dports 443,8443 \
        -m conntrack --ctstate NEW,ESTABLISHED \
        -j ACCEPT

    # Infusion pumps → ZTA Gateway (policy validation)
    iptables -A FORWARD \
        -s "$VLAN10" -d "$GW_IP" \
        -p tcp -m multiport --dports 443,8443 \
        -j ACCEPT

    # DENY all other traffic FROM infusion pumps (with logging)
    iptables -A FORWARD \
        -s "$VLAN10" \
        -m limit --limit 10/min --limit-burst 20 \
        -j LOG --log-prefix "$LOG_PREFIX INFUSION-PUMP-BLOCKED " --log-level "$LOG_LEVEL"
    iptables -A FORWARD -s "$VLAN10" -j DROP

    # DENY all traffic TO infusion pumps except from EHR (responses)
    iptables -A FORWARD \
        -d "$VLAN10" ! -s "$EHR_IP" \
        -m limit --limit 5/min --limit-burst 10 \
        -j LOG --log-prefix "$LOG_PREFIX INBOUND-PUMP-BLOCKED " --log-level "$LOG_LEVEL"
    iptables -A FORWARD -d "$VLAN10" ! -s "$EHR_IP" -j DROP

    # ── STEP 7: PATIENT MONITOR RULES (VLAN 20) ───────────────────────────────
    log_msg "Configuring Patient Monitor rules (VLAN 20)..."

    # Patient monitors → EHR (HTTPS)
    iptables -A FORWARD \
        -s "$VLAN20" -d "$EHR_IP" \
        -p tcp -m multiport --dports 443,8443 \
        -j ACCEPT

    # Patient monitors → Admin workstations (real-time stream port 5000)
    iptables -A FORWARD \
        -s "$VLAN20" -d "$VLAN40" \
        -p tcp --dport 5000 \
        -j ACCEPT

    # Patient monitors → ZTA Gateway
    iptables -A FORWARD \
        -s "$VLAN20" -d "$GW_IP" \
        -p tcp -m multiport --dports 443,8443 \
        -j ACCEPT

    # DENY cross-VLAN to imaging or pumps (lateral movement prevention)
    iptables -A FORWARD \
        -s "$VLAN20" -d "$VLAN10" \
        -j LOG --log-prefix "$LOG_PREFIX MONITOR-TO-PUMP-BLOCKED " --log-level "$LOG_LEVEL"
    iptables -A FORWARD -s "$VLAN20" -d "$VLAN10" -j DROP

    iptables -A FORWARD \
        -s "$VLAN20" -d "$VLAN30" \
        -j LOG --log-prefix "$LOG_PREFIX MONITOR-TO-IMAGING-BLOCKED " --log-level "$LOG_LEVEL"
    iptables -A FORWARD -s "$VLAN20" -d "$VLAN30" -j DROP

    # DENY remaining monitor traffic
    iptables -A FORWARD \
        -s "$VLAN20" ! -d "$EHR_IP" ! -d "$VLAN40" ! -d "$GW_IP" \
        -j LOG --log-prefix "$LOG_PREFIX MONITOR-BLOCKED " --log-level "$LOG_LEVEL"
    iptables -A FORWARD -s "$VLAN20" ! -d "$EHR_IP" ! -d "$VLAN40" ! -d "$GW_IP" -j DROP

    # ── STEP 8: IMAGING SYSTEM RULES (VLAN 30) ───────────────────────────────
    log_msg "Configuring Imaging System rules (VLAN 30 - DICOM/HTTPS)..."

    # Imaging → EHR (HTTPS + DICOM metadata)
    iptables -A FORWARD \
        -s "$VLAN30" -d "$EHR_IP" \
        -p tcp -m multiport --dports 443,104 \
        -j ACCEPT

    # Imaging → Admin workstations (DICOM C-STORE, HTTPS, DICOM)
    iptables -A FORWARD \
        -s "$VLAN30" -d "$VLAN40" \
        -p tcp -m multiport --dports 443,104,11112 \
        -j ACCEPT

    # Imaging → ZTA Gateway
    iptables -A FORWARD \
        -s "$VLAN30" -d "$GW_IP" \
        -p tcp -m multiport --dports 443,8443 \
        -j ACCEPT

    # Block imaging → pumps and monitors (strict segmentation)
    iptables -A FORWARD -s "$VLAN30" -d "$VLAN10" -j DROP
    iptables -A FORWARD -s "$VLAN30" -d "$VLAN20" -j DROP

    # Block remaining imaging traffic
    iptables -A FORWARD \
        -s "$VLAN30" \
        -j LOG --log-prefix "$LOG_PREFIX IMAGING-BLOCKED " --log-level "$LOG_LEVEL"
    iptables -A FORWARD -s "$VLAN30" -j DROP

    # ── STEP 9: ADMIN WORKSTATION RULES (VLAN 40) ─────────────────────────────
    log_msg "Configuring Admin Workstation rules (VLAN 40)..."

    # Admin → EHR (HTTPS)
    iptables -A FORWARD \
        -s "$VLAN40" -d "$EHR_IP" \
        -p tcp -m multiport --dports 443,8443 \
        -j ACCEPT

    # Admin → Patient Monitors (read monitoring data)
    iptables -A FORWARD \
        -s "$VLAN40" -d "$VLAN20" \
        -p tcp -m multiport --dports 443,8443,5000 \
        -j ACCEPT

    # Admin → Imaging Systems (clinical review)
    iptables -A FORWARD \
        -s "$VLAN40" -d "$VLAN30" \
        -p tcp -m multiport --dports 443,104,11112 \
        -j ACCEPT

    # Admin → ZTA Gateway
    iptables -A FORWARD \
        -s "$VLAN40" -d "$GW_IP" \
        -p tcp -m multiport --dports 443,8443,8000 \
        -j ACCEPT

    # DENY admin → infusion pumps (direct pump access denied — must go via EHR)
    iptables -A FORWARD \
        -s "$VLAN40" -d "$VLAN10" \
        -j LOG --log-prefix "$LOG_PREFIX ADMIN-TO-PUMP-BLOCKED " --log-level "$LOG_LEVEL"
    iptables -A FORWARD -s "$VLAN40" -d "$VLAN10" -j DROP

    # Block high-risk ports FROM admin (no direct SSH/RDP to medical devices)
    HIGHRI_PORTS="22 3389 445 21 23 69"
    for PORT in $HIGHRI_PORTS; do
        iptables -A FORWARD \
            -s "$VLAN40" -d "$VLAN10" -p tcp --dport "$PORT" \
            -j LOG --log-prefix "$LOG_PREFIX HIGH-RISK-PORT-$PORT " --log-level "$LOG_LEVEL"
        iptables -A FORWARD -s "$VLAN40" -d "$VLAN10" -p tcp --dport "$PORT" -j DROP
        iptables -A FORWARD -s "$VLAN40" -d "$VLAN20" -p tcp --dport "$PORT" -j DROP
        iptables -A FORWARD -s "$VLAN40" -d "$VLAN30" -p tcp --dport "$PORT" -j DROP
    done

    # ── STEP 10: MANAGEMENT VLAN RULES (VLAN 99) ──────────────────────────────
    log_msg "Configuring Management VLAN rules (VLAN 99)..."

    # ZTA Gateway can forward to all VLANs (policy-controlled at application layer)
    iptables -A FORWARD -s "$GW_IP"  -j ACCEPT
    iptables -A INPUT   -d "$GW_IP"  -p tcp --dport 8000 -j ACCEPT  # FastAPI

    # EHR Server: inbound from approved VLANs only
    iptables -A FORWARD \
        -s "$VLAN10" -d "$EHR_IP" -p tcp -m multiport --dports 443,8443 -j ACCEPT
    iptables -A FORWARD \
        -s "$VLAN20" -d "$EHR_IP" -p tcp -m multiport --dports 443,8443 -j ACCEPT
    iptables -A FORWARD \
        -s "$VLAN30" -d "$EHR_IP" -p tcp -m multiport --dports 443,104 -j ACCEPT
    iptables -A FORWARD \
        -s "$VLAN40" -d "$EHR_IP" -p tcp -m multiport --dports 443,8443 -j ACCEPT

    # ── STEP 11: ANTI-SPOOFING ────────────────────────────────────────────────
    log_msg "Configuring anti-spoofing rules..."

    # Block packets claiming to be from VLAN10 arriving on non-VLAN10 interface
    iptables -A FORWARD -s "$VLAN10" ! -i eth0.10 \
        -j LOG --log-prefix "$LOG_PREFIX IP-SPOOF-VLAN10 " --log-level 2"
    iptables -A FORWARD -s "$VLAN10" ! -i eth0.10 -j DROP

    # Block RFC 1918 private addresses arriving from external interface
    iptables -A INPUT -i eth0 -s 10.0.0.0/8    -j DROP
    iptables -A INPUT -i eth0 -s 172.16.0.0/12 -j DROP
    iptables -A INPUT -i eth0 -s 192.168.0.0/16 -j DROP

    # ── STEP 12: RATE LIMITING ────────────────────────────────────────────────
    log_msg "Applying rate limiting rules..."

    # Rate limit new connections from medical device VLANs
    iptables -A FORWARD \
        -s "$VLAN10,$VLAN20,$VLAN30" \
        -p tcp --syn \
        -m hashlimit \
        --hashlimit-name iomt-rate-limit \
        --hashlimit-upto 30/minute \
        --hashlimit-burst 10 \
        --hashlimit-mode srcip \
        -j ACCEPT

    # ── FINALIZE ──────────────────────────────────────────────────────────────
    log_msg "Zero Trust firewall rules applied successfully."
    log_msg "Default policies: INPUT=DROP, FORWARD=DROP, OUTPUT=DROP"
    log_msg "Allowed paths configured for $(iptables -L FORWARD --line-numbers | grep ACCEPT | wc -l) ACCEPT rules"

    # Save rules
    if command -v iptables-save &>/dev/null; then
        iptables-save > /etc/iptables/rules.v4 2>/dev/null || \
        iptables-save > /tmp/iptables-rules.v4
        log_msg "Rules saved."
    fi
}

# ── STATUS ─────────────────────────────────────────────────────────────────────

show_status() {
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "  ZERO TRUST IoMT FIREWALL STATUS"
    echo "═══════════════════════════════════════════════════════════════"
    echo ""
    echo "Default Policies:"
    iptables -L | grep "^Chain" | while read line; do echo "  $line"; done
    echo ""
    echo "FORWARD Chain Rules:"
    iptables -L FORWARD -n --line-numbers | head -60
    echo ""
    echo "Rule counts:"
    echo "  INPUT   : $(iptables -L INPUT --line-numbers | grep -c '^[0-9]') rules"
    echo "  FORWARD : $(iptables -L FORWARD --line-numbers | grep -c '^[0-9]') rules"
    echo "  OUTPUT  : $(iptables -L OUTPUT --line-numbers | grep -c '^[0-9]') rules"
    echo ""
}

# ── CONNECTIVITY TEST ──────────────────────────────────────────────────────────

test_rules() {
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "  FIREWALL RULE TEST (using iptables --check)"
    echo "═══════════════════════════════════════════════════════════════"
    echo ""

    # Test: Infusion pump → EHR should be ACCEPTED
    if iptables -C FORWARD -s "$VLAN10" -d "$EHR_IP" -p tcp --dport 443 -j ACCEPT 2>/dev/null; then
        echo "  [PASS] Infusion Pump → EHR:443 = ACCEPT"
    else
        echo "  [FAIL] Infusion Pump → EHR:443 = rule not found"
    fi

    # Test: Infusion pump → Patient Monitor should be DROPPED
    if iptables -C FORWARD -s "$VLAN10" -j DROP 2>/dev/null; then
        echo "  [PASS] Infusion Pump → Patient Monitor = DROP (catch-all)"
    else
        echo "  [INFO] Infusion pump catch-all DROP not found (check rules)"
    fi

    echo ""
}

# ── ENTRY POINT ────────────────────────────────────────────────────────────────

ACTION="${1:-apply}"

case "$ACTION" in
    apply)
        check_root
        apply_rules
        ;;
    flush)
        check_root
        flush_rules
        ;;
    status)
        show_status
        ;;
    test)
        test_rules
        ;;
    *)
        echo "Usage: $0 [apply|flush|status|test]"
        echo ""
        echo "  apply   — Apply Zero Trust IoMT firewall rules"
        echo "  flush   — Remove all rules, reset to ACCEPT"
        echo "  status  — Show current rule status"
        echo "  test    — Test key rules with iptables --check"
        exit 1
        ;;
esac
