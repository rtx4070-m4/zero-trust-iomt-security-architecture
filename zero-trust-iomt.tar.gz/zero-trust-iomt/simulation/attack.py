"""
attack.py — Advanced Attack Simulation Module
==============================================
Implements detailed attack scenarios against IoMT infrastructure.

Attack Scenarios:
  1. Compromised Infusion Pump — Lateral Movement
  2. Credential Stuffing on Admin Workstation
  3. DICOM Protocol Exploitation on Imaging System
  4. EHR Data Exfiltration via Rogue Monitor
  5. Denial of Service on Critical Device

Each scenario runs BEFORE and AFTER Zero Trust to demonstrate containment.

Usage:
    python attack.py --scenario all
    python attack.py --scenario lateral_movement
    python attack.py --scenario credential_stuffing
    python attack.py --list
"""

import sys
import os
import time
import argparse
import json
import random
from datetime import datetime, timezone
from typing import List, Dict, Callable

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from simulation.topology import IoMTTopology
from simulation.iomt_sim import IoMTSimulator, Packet
from monitoring.logger import IoMTLogger

# ── Colors ────────────────────────────────────────────────────────────────────
RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BLUE   = "\033[94m"
MAGENTA= "\033[95m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
RESET  = "\033[0m"


# ── Attack Result Tracker ─────────────────────────────────────────────────────

class AttackResult:
    def __init__(self, scenario_name: str):
        self.scenario_name = scenario_name
        self.steps: List[Dict] = []
        self.pre_zta_blocked = 0
        self.pre_zta_succeeded = 0
        self.post_zta_blocked = 0
        self.post_zta_succeeded = 0

    def record_step(self, description: str, pre_zta: bool, post_zta: bool):
        self.steps.append({
            "description": description,
            "pre_zta_result": "SUCCEEDED" if pre_zta else "BLOCKED",
            "post_zta_result": "BLOCKED" if not post_zta else "SUCCEEDED",
        })
        if pre_zta:
            self.pre_zta_succeeded += 1
        else:
            self.pre_zta_blocked += 1
        if not post_zta:
            self.post_zta_blocked += 1
        else:
            self.post_zta_succeeded += 1

    def summary(self) -> str:
        lines = [
            f"\n{BOLD}  Attack Scenario: {self.scenario_name}{RESET}",
            f"  {'─' * 60}",
            f"  {'Step':<45} {'Pre-ZTA':<12} {'Post-ZTA':<12}",
            f"  {'─' * 60}",
        ]
        for step in self.steps:
            pre  = f"{RED}SUCCEEDED{RESET}" if step["pre_zta_result"]  == "SUCCEEDED" else f"{GREEN}BLOCKED{RESET}"
            post = f"{RED}SUCCEEDED{RESET}" if step["post_zta_result"] == "SUCCEEDED" else f"{GREEN}BLOCKED{RESET}"
            desc = step["description"][:43]
            lines.append(f"  {desc:<45} {pre:<20} {post}")
        lines.append(f"  {'─' * 60}")
        lines.append(
            f"  {RED}Pre-ZTA  : {self.pre_zta_succeeded} succeeded / {self.pre_zta_blocked} blocked{RESET}"
        )
        lines.append(
            f"  {GREEN}Post-ZTA : {self.post_zta_succeeded} succeeded / {self.post_zta_blocked} blocked{RESET}"
        )
        effectiveness = (self.post_zta_blocked / max(1, len(self.steps))) * 100
        lines.append(f"\n  {BOLD}ZTA Effectiveness: {effectiveness:.0f}% of attack vectors contained{RESET}\n")
        return "\n".join(lines)


# ── Attack Scenarios ──────────────────────────────────────────────────────────

class AttackSimulator:
    """Runs structured attack scenarios against the IoMT topology."""

    def __init__(self):
        self.logger = IoMTLogger()
        self.results: List[AttackResult] = []

    def _banner(self, title: str, color: str = RED):
        width = 65
        print(f"\n{BOLD}{color}{'═' * width}{RESET}")
        print(f"{BOLD}{color}  {title}{RESET}")
        print(f"{BOLD}{color}{'═' * width}{RESET}\n")

    def _step(self, label: str, detail: str):
        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        print(f"  {DIM}[{ts}]{RESET} {YELLOW}{label}{RESET}")
        print(f"  {' ' * 10}{DIM}{detail}{RESET}")

    # ── Scenario 1: Lateral Movement from Compromised Pump ────────────────────

    def scenario_lateral_movement(self) -> AttackResult:
        """
        MITRE ATT&CK: T0866 (Exploitation of Remote Services)
        A compromised infusion pump attempts to move laterally
        to patient monitors, imaging systems, and the EHR.
        """
        self._banner("SCENARIO 1: LATERAL MOVEMENT — Compromised Infusion Pump", RED)

        print(f"  {CYAN}Threat Actor   : Advanced Persistent Threat (APT) group{RESET}")
        print(f"  {CYAN}Entry Point    : InfusionPump-ICU-01 (IP-001) via firmware exploit{RESET}")
        print(f"  {CYAN}MITRE ATT&CK   : T0866 — Exploitation of Remote Services{RESET}")
        print(f"  {CYAN}Target         : PHI data on EHR server + device manipulation{RESET}\n")

        result = AttackResult("Lateral Movement — Compromised Infusion Pump")

        attack_steps = [
            # (description, src, dst_ip, port, payload_type)
            ("Recon: Probe patient monitor VLAN",
             "IP-001", "10.0.20.11", 5000, "tcp-syn-probe"),
            ("Exploit: DICOM buffer overflow on MRI",
             "IP-001", "10.0.30.11", 104, "dicom-exploit-cve-2021-41769"),
            ("Pivot: RDP brute-force on admin workstation",
             "IP-001", "10.0.40.10", 3389, "rdp-brute-force"),
            ("Exfil: PHI dump from EHR server (443)",
             "IP-001", "10.0.99.20", 443, "data-exfiltration-phi"),
            ("C2: Beacon to external C2 server",
             "IP-001", "203.0.113.50", 8080, "c2-beacon-cobaltstrike"),
            ("Persist: Modify patient monitor firmware",
             "IP-001", "10.0.20.12", 22, "ssh-firmware-implant"),
        ]

        for desc, src, dst, port, payload in attack_steps:
            self._step(f"[ATK] {desc}", f"{src} → {dst}:{port} ({payload})")

            # Pre-ZTA (flat network)
            flat_sim = IoMTSimulator(zero_trust_enabled=False)
            pre_pkt = Packet(src, dst, port, payload_type=payload, flags=["SYN"])
            pre_result = flat_sim.transmit(pre_pkt)

            # Post-ZTA (Zero Trust active)
            zta_sim = IoMTSimulator(zero_trust_enabled=True)
            compromised = zta_sim.topology.get_device("IP-001")
            if compromised:
                compromised.compromised = True
                compromised.trust_score = 0.0
                compromised.authorized = False
            post_pkt = Packet(src, dst, port, payload_type=payload, flags=["SYN"])
            post_result = zta_sim.transmit(post_pkt)

            pre_label  = f"{RED}ATTACK SUCCEEDED{RESET}" if pre_result  else f"{GREEN}BLOCKED{RESET}"
            post_label = f"{RED}ATTACK SUCCEEDED{RESET}" if post_result else f"{GREEN}BLOCKED ✓{RESET}"

            print(f"  {'─' * 55}")
            print(f"  Pre-ZTA  → {pre_label}")
            print(f"  Post-ZTA → {post_label}\n")

            result.record_step(desc, pre_result, post_result)
            time.sleep(0.15)

        print(result.summary())
        self.results.append(result)
        return result

    # ── Scenario 2: Credential Stuffing ──────────────────────────────────────

    def scenario_credential_stuffing(self) -> AttackResult:
        """
        MITRE ATT&CK: T1110 (Brute Force)
        Attacker uses leaked credential list against admin workstation.
        """
        self._banner("SCENARIO 2: CREDENTIAL STUFFING — Admin Workstation", MAGENTA)

        print(f"  {CYAN}Threat Actor   : Ransomware affiliate group{RESET}")
        print(f"  {CYAN}Entry Point    : External attacker targeting clinical workstation{RESET}")
        print(f"  {CYAN}MITRE ATT&CK   : T1110 — Brute Force / Credential Stuffing{RESET}")
        print(f"  {CYAN}Target         : Admin access → EHR database{RESET}\n")

        result = AttackResult("Credential Stuffing — Admin Workstation")

        # Simulate rogue device (not in our registry)
        rogue_device_id = "ROGUE-EXT-001"

        attack_steps = [
            ("Recon: Port scan admin workstation",
             rogue_device_id, "10.0.40.10", 443, "tcp-port-scan"),
            ("Auth: Credential stuffing (1000 attempts)",
             rogue_device_id, "10.0.40.10", 443, "credential-stuffing"),
            ("Pivot: Access EHR via compromised creds",
             rogue_device_id, "10.0.99.20", 443, "stolen-credential-access"),
            ("Exfil: Download patient records",
             rogue_device_id, "10.0.99.20", 443, "data-exfiltration-records"),
            ("Ransom: Deploy ransomware payload",
             rogue_device_id, "10.0.40.10", 445, "ransomware-smb-deploy"),
        ]

        for desc, src, dst, port, payload in attack_steps:
            self._step(f"[ATK] {desc}", f"ROGUE-EXT → {dst}:{port} ({payload})")

            flat_sim = IoMTSimulator(zero_trust_enabled=False)
            # Inject rogue device into flat_sim topology with no restrictions
            from simulation.topology import IoMTDevice
            rogue = IoMTDevice(
                device_id=rogue_device_id, name="Rogue-Device", role="admin_workstation",
                ip="10.0.40.99", mac="00:DE:AD:BE:EF:01",
                cert_thumbprint="SHA256:INVALID",
                firmware_version="unknown", vendor="unknown",
                allowed_destinations=["0.0.0.0/0"],
                allowed_ports=list(range(1, 65536)),
            )
            flat_sim.topology.devices[rogue_device_id] = rogue
            pre_pkt = Packet(rogue_device_id, dst, port, payload_type=payload)
            pre_result = flat_sim.transmit(pre_pkt)

            # In ZTA: rogue device has no valid cert → denied immediately
            zta_sim = IoMTSimulator(zero_trust_enabled=True)
            # Do NOT add rogue to ZTA topology — it's unknown
            post_pkt = Packet(rogue_device_id, dst, port, payload_type=payload)
            post_result = zta_sim.transmit(post_pkt)

            pre_label  = f"{RED}ATTACK SUCCEEDED{RESET}" if pre_result  else f"{GREEN}BLOCKED{RESET}"
            post_label = f"{RED}ATTACK SUCCEEDED{RESET}" if post_result else f"{GREEN}BLOCKED ✓{RESET}"

            print(f"  {'─' * 55}")
            print(f"  Pre-ZTA  → {pre_label}")
            print(f"  Post-ZTA → {post_label}\n")

            result.record_step(desc, pre_result, post_result)
            time.sleep(0.1)

        print(result.summary())
        self.results.append(result)
        return result

    # ── Scenario 3: DICOM Exploitation on Imaging System ──────────────────────

    def scenario_dicom_exploit(self) -> AttackResult:
        """
        CVE-2021-41769: Simulated DICOM protocol attack against imaging systems.
        """
        self._banner("SCENARIO 3: DICOM PROTOCOL EXPLOITATION — MRI/CT Scanner", YELLOW)

        print(f"  {CYAN}Threat Actor   : Nation-state APT targeting healthcare{RESET}")
        print(f"  {CYAN}Entry Point    : Imaging VLAN via unpatched DICOM service{RESET}")
        print(f"  {CYAN}CVE Reference  : CVE-2021-41769 (simulated){RESET}")
        print(f"  {CYAN}Target         : DICOM archive → PHI exfiltration{RESET}\n")

        result = AttackResult("DICOM Exploitation — Imaging System")

        attack_steps = [
            ("Discovery: DICOM C-ECHO probe (unauthenticated)",
             "IP-001", "10.0.30.11", 104, "dicom-c-echo"),
            ("Exploit: Malformed DICOM PDU (buffer overflow)",
             "IP-001", "10.0.30.11", 11112, "dicom-pdu-exploit"),
            ("Exfil: C-FIND all patient studies",
             "IP-001", "10.0.30.12", 104, "dicom-c-find-all"),
            ("Exfil: C-MOVE bulk image exfiltration",
             "IP-001", "10.0.30.12", 104, "dicom-c-move-exfil"),
            ("Persist: Backdoor via C-STORE injection",
             "IP-001", "10.0.30.11", 11112, "dicom-c-store-implant"),
        ]

        for desc, src, dst, port, payload in attack_steps:
            self._step(f"[ATK] {desc}", f"{src} → {dst}:{port}")

            flat_sim = IoMTSimulator(zero_trust_enabled=False)
            pre_pkt = Packet(src, dst, port, payload_type=payload)
            pre_result = flat_sim.transmit(pre_pkt)

            zta_sim = IoMTSimulator(zero_trust_enabled=True)
            compromised = zta_sim.topology.get_device("IP-001")
            if compromised:
                compromised.compromised = True
                compromised.authorized = False
                compromised.trust_score = 0.0
            post_pkt = Packet(src, dst, port, payload_type=payload)
            post_result = zta_sim.transmit(post_pkt)

            pre_label  = f"{RED}ATTACK SUCCEEDED{RESET}" if pre_result  else f"{GREEN}BLOCKED{RESET}"
            post_label = f"{RED}ATTACK SUCCEEDED{RESET}" if post_result else f"{GREEN}BLOCKED ✓{RESET}"

            print(f"  {'─' * 55}")
            print(f"  Pre-ZTA  → {pre_label}")
            print(f"  Post-ZTA → {post_label}\n")

            result.record_step(desc, pre_result, post_result)
            time.sleep(0.1)

        print(result.summary())
        self.results.append(result)
        return result

    # ── Scenario 4: DoS on Critical Device ────────────────────────────────────

    def scenario_dos_attack(self) -> AttackResult:
        """
        T0814: Denial of Service targeting a patient monitor.
        Could cause loss of vital sign monitoring in ICU.
        """
        self._banner("SCENARIO 4: DENIAL OF SERVICE — ICU Patient Monitor", RED)

        print(f"  {CYAN}Threat Actor   : Disgruntled insider / ransomware group{RESET}")
        print(f"  {CYAN}Entry Point    : Admin workstation (insider threat){RESET}")
        print(f"  {CYAN}MITRE ATT&CK   : T0814 — Denial of Service{RESET}")
        print(f"  {CYAN}Impact         : Loss of vital sign monitoring (patient safety risk){RESET}\n")

        result = AttackResult("Denial of Service — ICU Patient Monitor")

        attack_steps = [
            ("SYN Flood: Saturate patient monitor",
             "AW-001", "10.0.20.11", 5000, "syn-flood"),
            ("ICMP Flood: Broadcast amplification",
             "AW-001", "10.0.20.11", 0, "icmp-flood"),
            ("HTTP Flood: REST API exhaustion",
             "AW-001", "10.0.20.11", 443, "http-flood"),
            ("Resource Exhaustion: Telnet login storm",
             "AW-001", "10.0.20.12", 23, "telnet-exhaustion"),
        ]

        for desc, src, dst, port, payload in attack_steps:
            self._step(f"[ATK] {desc}", f"{src} → {dst}:{port}")

            flat_sim = IoMTSimulator(zero_trust_enabled=False)
            pre_pkt = Packet(src, dst, port, payload_type=payload,
                             flags=["SYN"] * 1000, payload_size=65535)
            pre_result = flat_sim.transmit(pre_pkt)

            zta_sim = IoMTSimulator(zero_trust_enabled=True)
            post_pkt = Packet(src, dst, port, payload_type=payload,
                              flags=["SYN"] * 1000, payload_size=65535)
            post_result = zta_sim.transmit(post_pkt)

            pre_label  = f"{RED}ATTACK SUCCEEDED{RESET}" if pre_result  else f"{GREEN}BLOCKED{RESET}"
            post_label = f"{RED}ATTACK SUCCEEDED{RESET}" if post_result else f"{GREEN}BLOCKED ✓{RESET}"

            print(f"  {'─' * 55}")
            print(f"  Pre-ZTA  → {pre_label}")
            print(f"  Post-ZTA → {post_label}\n")

            result.record_step(desc, pre_result, post_result)
            time.sleep(0.1)

        print(result.summary())
        self.results.append(result)
        return result

    # ── Master Report ─────────────────────────────────────────────────────────

    def print_master_report(self):
        """Print consolidated attack containment report across all scenarios."""
        print(f"\n{BOLD}{BLUE}{'═' * 65}{RESET}")
        print(f"{BOLD}{BLUE}  ZERO TRUST ATTACK CONTAINMENT — MASTER REPORT{RESET}")
        print(f"{BOLD}{BLUE}{'═' * 65}{RESET}\n")

        total_steps   = sum(len(r.steps) for r in self.results)
        total_pre_suc = sum(r.pre_zta_succeeded for r in self.results)
        total_post_blk= sum(r.post_zta_blocked  for r in self.results)
        effectiveness  = (total_post_blk / max(1, total_steps)) * 100

        print(f"  {'Scenario':<45} {'Pre-ZTA Win':<12} {'Post-ZTA Blk'}")
        print(f"  {'─' * 65}")
        for r in self.results:
            print(f"  {r.scenario_name[:45]:<45} "
                  f"{RED}{r.pre_zta_succeeded}/{len(r.steps)}{RESET}         "
                  f"{GREEN}{r.post_zta_blocked}/{len(r.steps)}{RESET}")
        print(f"  {'─' * 65}")
        print(f"  {'TOTAL':<45} {RED}{total_pre_suc}/{total_steps}{RESET}         "
              f"{GREEN}{total_post_blk}/{total_steps}{RESET}")
        print(f"\n  {BOLD}Overall ZTA Attack Containment Rate: {effectiveness:.1f}%{RESET}")
        print(f"\n  {DIM}Logs saved to logs/attack_events.jsonl{RESET}")
        print(f"{BOLD}{BLUE}{'═' * 65}{RESET}\n")

        # Export JSON report
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total_attack_steps": total_steps,
            "pre_zta_attacks_succeeded": total_pre_suc,
            "post_zta_attacks_blocked": total_post_blk,
            "zta_containment_rate_pct": round(effectiveness, 1),
            "scenarios": [
                {
                    "name": r.scenario_name,
                    "steps": r.steps,
                    "pre_zta_succeeded": r.pre_zta_succeeded,
                    "post_zta_blocked": r.post_zta_blocked,
                }
                for r in self.results
            ],
        }
        os.makedirs("logs", exist_ok=True)
        with open("logs/attack_report.json", "w") as f:
            json.dump(report, f, indent=2)


# ── Entry Point ────────────────────────────────────────────────────────────────

SCENARIO_MAP: Dict[str, Callable] = {}

def main():
    parser = argparse.ArgumentParser(description="IoMT Attack Simulation Engine")
    parser.add_argument(
        "--scenario",
        choices=["all", "lateral_movement", "credential_stuffing",
                 "dicom_exploit", "dos_attack"],
        default="all",
        help="Attack scenario to run",
    )
    parser.add_argument("--list", action="store_true", help="List available scenarios")
    args = parser.parse_args()

    if args.list:
        print("\nAvailable Attack Scenarios:")
        print("  lateral_movement    — Compromised pump lateral movement")
        print("  credential_stuffing — Admin workstation credential stuffing")
        print("  dicom_exploit       — DICOM protocol exploitation")
        print("  dos_attack          — DoS on ICU patient monitor")
        print("  all                 — Run all scenarios\n")
        return

    print(f"\n{BOLD}{RED}")
    print("  ╔══════════════════════════════════════════════════════╗")
    print("  ║      IoMT ATTACK SIMULATION ENGINE v2.1.0           ║")
    print("  ║      Zero Trust Containment Proof-of-Concept        ║")
    print("  ╚══════════════════════════════════════════════════════╝")
    print(f"{RESET}")

    atk = AttackSimulator()

    scenario_map = {
        "lateral_movement":     atk.scenario_lateral_movement,
        "credential_stuffing":  atk.scenario_credential_stuffing,
        "dicom_exploit":        atk.scenario_dicom_exploit,
        "dos_attack":           atk.scenario_dos_attack,
    }

    if args.scenario == "all":
        for fn in scenario_map.values():
            fn()
            time.sleep(0.3)
    else:
        scenario_map[args.scenario]()

    atk.print_master_report()


if __name__ == "__main__":
    main()
