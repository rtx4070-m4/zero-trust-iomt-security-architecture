"""
topology.py — IoMT Network Topology Definition
=================================================
Defines the logical network segments (VLANs) and device inventory
for the Zero Trust IoMT simulation environment.

Segments:
  VLAN 10 — Infusion Pumps        (10.0.10.0/24)
  VLAN 20 — Patient Monitors      (10.0.20.0/24)
  VLAN 30 — Imaging Systems       (10.0.30.0/24)
  VLAN 40 — Admin / Clinical IT   (10.0.40.0/24)
  VLAN 99 — Management / ZTA Core (10.0.99.0/24)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
import json

# ── Device Roles ──────────────────────────────────────────────────────────────

ROLES = {
    "infusion_pump":    {"vlan": 10, "subnet": "10.0.10.0/24", "risk_level": "high"},
    "patient_monitor":  {"vlan": 20, "subnet": "10.0.20.0/24", "risk_level": "medium"},
    "imaging_system":   {"vlan": 30, "subnet": "10.0.30.0/24", "risk_level": "high"},
    "admin_workstation":{"vlan": 40, "subnet": "10.0.40.0/24", "risk_level": "low"},
    "ehr_server":       {"vlan": 99, "subnet": "10.0.99.0/24", "risk_level": "critical"},
    "zta_gateway":      {"vlan": 99, "subnet": "10.0.99.0/24", "risk_level": "critical"},
}

# ── Device Registry ───────────────────────────────────────────────────────────

@dataclass
class IoMTDevice:
    """Represents a single medical IoT device in the network."""
    device_id: str
    name: str
    role: str
    ip: str
    mac: str
    cert_thumbprint: str
    firmware_version: str
    vendor: str
    authorized: bool = True
    compromised: bool = False
    trust_score: float = 1.0          # 0.0 (untrusted) → 1.0 (fully trusted)
    allowed_destinations: List[str] = field(default_factory=list)
    allowed_ports: List[int] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)

    def vlan(self) -> int:
        return ROLES[self.role]["vlan"]

    def subnet(self) -> str:
        return ROLES[self.role]["subnet"]

    def risk_level(self) -> str:
        return ROLES[self.role]["risk_level"]

    def to_dict(self) -> Dict:
        return {
            "device_id": self.device_id,
            "name": self.name,
            "role": self.role,
            "ip": self.ip,
            "mac": self.mac,
            "cert_thumbprint": self.cert_thumbprint,
            "firmware_version": self.firmware_version,
            "vendor": self.vendor,
            "authorized": self.authorized,
            "compromised": self.compromised,
            "trust_score": self.trust_score,
            "vlan": self.vlan(),
            "subnet": self.subnet(),
            "risk_level": self.risk_level(),
            "allowed_destinations": self.allowed_destinations,
            "allowed_ports": self.allowed_ports,
            "tags": self.tags,
        }


# ── Network Topology ──────────────────────────────────────────────────────────

class IoMTTopology:
    """
    Manages the full IoMT network topology including devices, segments,
    and allowed communication paths (the Zero Trust allow-list).
    """

    def __init__(self):
        self.devices: Dict[str, IoMTDevice] = {}
        self._build_topology()

    def _build_topology(self):
        """Populate the simulated device inventory."""

        device_definitions = [
            # ── Infusion Pumps (VLAN 10) ──────────────────────────────────────
            IoMTDevice(
                device_id="IP-001",
                name="InfusionPump-ICU-01",
                role="infusion_pump",
                ip="10.0.10.11",
                mac="AA:BB:CC:10:00:11",
                cert_thumbprint="SHA256:a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2",
                firmware_version="3.2.1",
                vendor="MedFusion Inc.",
                allowed_destinations=["10.0.99.20"],   # Only EHR server
                allowed_ports=[443, 8443],
                tags=["icu", "critical-care"],
            ),
            IoMTDevice(
                device_id="IP-002",
                name="InfusionPump-ICU-02",
                role="infusion_pump",
                ip="10.0.10.12",
                mac="AA:BB:CC:10:00:12",
                cert_thumbprint="SHA256:b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3",
                firmware_version="3.2.1",
                vendor="MedFusion Inc.",
                allowed_destinations=["10.0.99.20"],
                allowed_ports=[443, 8443],
                tags=["icu", "critical-care"],
            ),
            IoMTDevice(
                device_id="IP-003",
                name="InfusionPump-Ward-01",
                role="infusion_pump",
                ip="10.0.10.21",
                mac="AA:BB:CC:10:00:21",
                cert_thumbprint="SHA256:c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4",
                firmware_version="3.1.9",
                vendor="MedFusion Inc.",
                allowed_destinations=["10.0.99.20"],
                allowed_ports=[443, 8443],
                tags=["ward", "general"],
            ),

            # ── Patient Monitors (VLAN 20) ─────────────────────────────────────
            IoMTDevice(
                device_id="PM-001",
                name="PatientMonitor-ICU-01",
                role="patient_monitor",
                ip="10.0.20.11",
                mac="AA:BB:CC:20:00:11",
                cert_thumbprint="SHA256:d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5",
                firmware_version="5.0.3",
                vendor="VitalTrack Systems",
                allowed_destinations=["10.0.99.20", "10.0.40.10"],
                allowed_ports=[443, 8443, 5000],
                tags=["icu", "vitals", "real-time"],
            ),
            IoMTDevice(
                device_id="PM-002",
                name="PatientMonitor-ICU-02",
                role="patient_monitor",
                ip="10.0.20.12",
                mac="AA:BB:CC:20:00:12",
                cert_thumbprint="SHA256:e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6",
                firmware_version="5.0.3",
                vendor="VitalTrack Systems",
                allowed_destinations=["10.0.99.20", "10.0.40.10"],
                allowed_ports=[443, 8443, 5000],
                tags=["icu", "vitals", "real-time"],
            ),
            IoMTDevice(
                device_id="PM-003",
                name="PatientMonitor-Ward-01",
                role="patient_monitor",
                ip="10.0.20.21",
                mac="AA:BB:CC:20:00:21",
                cert_thumbprint="SHA256:f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1",
                firmware_version="4.9.1",
                vendor="VitalTrack Systems",
                allowed_destinations=["10.0.99.20"],
                allowed_ports=[443, 8443],
                tags=["ward", "vitals"],
            ),

            # ── Imaging Systems (VLAN 30) ─────────────────────────────────────
            IoMTDevice(
                device_id="IS-001",
                name="MRI-Scanner-01",
                role="imaging_system",
                ip="10.0.30.11",
                mac="AA:BB:CC:30:00:11",
                cert_thumbprint="SHA256:a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6b2c3",
                firmware_version="12.4.0",
                vendor="ImagingPro Ltd.",
                allowed_destinations=["10.0.99.20", "10.0.40.10"],
                allowed_ports=[104, 443, 11112],  # DICOM + HTTPS
                tags=["radiology", "dicom", "large-data"],
            ),
            IoMTDevice(
                device_id="IS-002",
                name="CT-Scanner-01",
                role="imaging_system",
                ip="10.0.30.12",
                mac="AA:BB:CC:30:00:12",
                cert_thumbprint="SHA256:b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6c3d4e5",
                firmware_version="8.1.2",
                vendor="ScanTech Medical",
                allowed_destinations=["10.0.99.20", "10.0.40.10"],
                allowed_ports=[104, 443, 11112],
                tags=["radiology", "dicom"],
            ),

            # ── Admin Workstations (VLAN 40) ──────────────────────────────────
            IoMTDevice(
                device_id="AW-001",
                name="ClinicalWorkstation-01",
                role="admin_workstation",
                ip="10.0.40.10",
                mac="AA:BB:CC:40:00:10",
                cert_thumbprint="SHA256:c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6d4e5f6a1",
                firmware_version="Win11-22H2",
                vendor="Dell Technologies",
                allowed_destinations=["10.0.99.20", "10.0.20.11", "10.0.20.12",
                                       "10.0.30.11", "10.0.30.12"],
                allowed_ports=[443, 8443, 3389, 5000, 104],
                tags=["clinical", "admin", "user-facing"],
            ),
            IoMTDevice(
                device_id="AW-002",
                name="NurseStation-Workstation-01",
                role="admin_workstation",
                ip="10.0.40.11",
                mac="AA:BB:CC:40:00:11",
                cert_thumbprint="SHA256:d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6e5f6a1b2c3",
                firmware_version="Win11-22H2",
                vendor="HP Inc.",
                allowed_destinations=["10.0.99.20", "10.0.20.11", "10.0.20.12",
                                       "10.0.20.21"],
                allowed_ports=[443, 8443, 5000],
                tags=["nursing", "admin"],
            ),

            # ── Core Infrastructure (VLAN 99) ─────────────────────────────────
            IoMTDevice(
                device_id="EHR-001",
                name="EHR-Server-Primary",
                role="ehr_server",
                ip="10.0.99.20",
                mac="AA:BB:CC:99:00:20",
                cert_thumbprint="SHA256:e5f6a1b2c3d4e5f6a1b2c3d4e5f6f6a1b2c3d4e5",
                firmware_version="RHEL-9.2",
                vendor="Epic Systems",
                allowed_destinations=[],          # Responds only; never initiates
                allowed_ports=[443, 8443],
                tags=["ehr", "phi", "core-infra"],
            ),
            IoMTDevice(
                device_id="GW-001",
                name="ZTA-Gateway-01",
                role="zta_gateway",
                ip="10.0.99.10",
                mac="AA:BB:CC:99:00:10",
                cert_thumbprint="SHA256:f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1",
                firmware_version="ZTA-Engine-2.1.0",
                vendor="Internal",
                allowed_destinations=["0.0.0.0/0"],  # Gateway can reach everywhere
                allowed_ports=[443, 8443, 80, 8080],
                tags=["zta", "gateway", "policy-enforcement"],
            ),
        ]

        for device in device_definitions:
            self.devices[device.device_id] = device

    # ── Query Methods ─────────────────────────────────────────────────────────

    def get_device(self, device_id: str) -> Optional[IoMTDevice]:
        return self.devices.get(device_id)

    def get_devices_by_role(self, role: str) -> List[IoMTDevice]:
        return [d for d in self.devices.values() if d.role == role]

    def get_devices_by_vlan(self, vlan: int) -> List[IoMTDevice]:
        return [d for d in self.devices.values() if d.vlan() == vlan]

    def get_compromised_devices(self) -> List[IoMTDevice]:
        return [d for d in self.devices.values() if d.compromised]

    def is_communication_allowed(self, src_id: str, dst_ip: str, port: int) -> bool:
        """
        Zero Trust policy check: is device src_id allowed to communicate
        with dst_ip on the given port?
        """
        src = self.get_device(src_id)
        if not src:
            return False
        if not src.authorized or src.trust_score < 0.5:
            return False
        if dst_ip not in src.allowed_destinations:
            return False
        if port not in src.allowed_ports:
            return False
        return True

    def export_inventory(self, path: str = "device_inventory.json"):
        """Export full device inventory as JSON."""
        inventory = {dev_id: dev.to_dict() for dev_id, dev in self.devices.items()}
        with open(path, "w") as f:
            json.dump(inventory, f, indent=2)
        print(f"[topology] Device inventory exported to {path}")

    def print_summary(self):
        """Print a formatted topology summary."""
        print("\n" + "═" * 65)
        print("  IoMT NETWORK TOPOLOGY SUMMARY")
        print("═" * 65)
        vlan_map = {}
        for dev in self.devices.values():
            vlan_map.setdefault(dev.vlan(), []).append(dev)

        for vlan_id in sorted(vlan_map.keys()):
            role_name = next(
                (r for r, v in ROLES.items() if v["vlan"] == vlan_id), "unknown"
            )
            subnet = next(
                (v["subnet"] for v in ROLES.values() if v["vlan"] == vlan_id), ""
            )
            print(f"\n  VLAN {vlan_id:02d} | {subnet:18s} | {role_name}")
            print("  " + "─" * 60)
            for dev in vlan_map[vlan_id]:
                status = "⚠ COMPROMISED" if dev.compromised else "✓ OK"
                print(f"    [{dev.device_id}] {dev.name:<35} {dev.ip:<15} {status}")
        print("\n" + "═" * 65 + "\n")


# ── Standalone run ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    topo = IoMTTopology()
    topo.print_summary()
    topo.export_inventory("/tmp/device_inventory.json")
