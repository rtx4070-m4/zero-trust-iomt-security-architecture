"""
iomt_sim.py — IoMT Network Communication Simulator
====================================================
Simulates both LEGITIMATE and MALICIOUS network traffic across the IoMT
topology without requiring Mininet (runs in pure Python for portability).

Legitimate flows are checked against the Zero Trust policy engine before
being allowed or denied. All events are emitted to the logger.

Usage:
    python iomt_sim.py --mode normal     # Run legitimate traffic
    python iomt_sim.py --mode attack     # Run attack simulation
    python iomt_sim.py --mode full       # Both (default)
    python iomt_sim.py --mode demo       # Step-by-step demo output
"""

import time
import random
import argparse
import json
import sys
import os
from datetime import datetime, timezone
from typing import Optional

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from simulation.topology import IoMTTopology, IoMTDevice
from policies.policy_engine import ZeroTrustPolicyEngine
from monitoring.logger import IoMTLogger

# ── ANSI Colors ───────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BLUE   = "\033[94m"
BOLD   = "\033[1m"
RESET  = "\033[0m"
DIM    = "\033[2m"


# ── Traffic Packet Representation ────────────────────────────────────────────

class Packet:
    """Represents a simulated network packet."""

    def __init__(
        self,
        src_device_id: str,
        dst_ip: str,
        dst_port: int,
        protocol: str = "TCP",
        payload_size: int = 512,
        payload_type: str = "hl7v2",
        flags: Optional[list] = None,
    ):
        self.src_device_id = src_device_id
        self.dst_ip = dst_ip
        self.dst_port = dst_port
        self.protocol = protocol
        self.payload_size = payload_size
        self.payload_type = payload_type
        self.flags = flags or []
        self.timestamp = datetime.now(timezone.utc).isoformat()
        self.packet_id = f"PKT-{int(time.time() * 1000) % 100000:05d}"

    def to_dict(self) -> dict:
        return {
            "packet_id": self.packet_id,
            "timestamp": self.timestamp,
            "src_device_id": self.src_device_id,
            "dst_ip": self.dst_ip,
            "dst_port": self.dst_port,
            "protocol": self.protocol,
            "payload_size": self.payload_size,
            "payload_type": self.payload_type,
            "flags": self.flags,
        }


# ── IoMT Traffic Simulator ────────────────────────────────────────────────────

class IoMTSimulator:
    """
    Simulates IoMT network traffic with Zero Trust policy enforcement.
    """

    def __init__(self, zero_trust_enabled: bool = True):
        self.topology = IoMTTopology()
        self.policy_engine = ZeroTrustPolicyEngine(self.topology)
        self.logger = IoMTLogger()
        self.zero_trust_enabled = zero_trust_enabled
        self.stats = {
            "packets_sent": 0,
            "packets_allowed": 0,
            "packets_blocked": 0,
            "attacks_detected": 0,
        }

    # ── Core Transmission Logic ───────────────────────────────────────────────

    def transmit(self, packet: Packet, description: str = "") -> bool:
        """
        Attempt to transmit a packet through the Zero Trust gateway.
        Returns True if allowed, False if blocked.
        """
        self.stats["packets_sent"] += 1
        src_device = self.topology.get_device(packet.src_device_id)
        src_ip = src_device.ip if src_device else "UNKNOWN"

        if self.zero_trust_enabled:
            decision = self.policy_engine.evaluate(packet)
            allowed = decision["allowed"]
            reason  = decision["reason"]
        else:
            # Pre-ZTA: flat network, everything allowed
            allowed = True
            reason  = "FLAT_NETWORK_NO_ENFORCEMENT"

        if allowed:
            self.stats["packets_allowed"] += 1
            self.logger.log_allow(packet, src_ip, reason)
        else:
            self.stats["packets_blocked"] += 1
            if "ATTACK" in (decision.get("threat_level", "") if self.zero_trust_enabled else ""):
                self.stats["attacks_detected"] += 1
            self.logger.log_deny(packet, src_ip, reason)

        return allowed

    # ── Legitimate Traffic Scenarios ──────────────────────────────────────────

    def run_normal_traffic(self, verbose: bool = True):
        """Simulate normal IoMT operational communication flows."""
        if verbose:
            print(f"\n{BOLD}{CYAN}{'═' * 65}{RESET}")
            print(f"{BOLD}{CYAN}  PHASE 1: LEGITIMATE IoMT COMMUNICATION FLOWS{RESET}")
            print(f"{BOLD}{CYAN}{'═' * 65}{RESET}\n")

        normal_flows = [
            # Infusion pumps → EHR server (telemetry)
            (Packet("IP-001", "10.0.99.20", 8443, payload_type="hl7v2-telemetry", payload_size=256),
             "InfusionPump-ICU-01 → EHR: Medication dosage telemetry"),
            (Packet("IP-002", "10.0.99.20", 8443, payload_type="hl7v2-telemetry", payload_size=256),
             "InfusionPump-ICU-02 → EHR: Medication dosage telemetry"),
            (Packet("IP-003", "10.0.99.20", 8443, payload_type="hl7v2-alert", payload_size=128),
             "InfusionPump-Ward-01 → EHR: Low-drug alert"),

            # Patient monitors → EHR server (vital signs)
            (Packet("PM-001", "10.0.99.20", 443, payload_type="fhir-r4-vitals", payload_size=512),
             "PatientMonitor-ICU-01 → EHR: Vital signs (HR, SpO2, BP)"),
            (Packet("PM-002", "10.0.99.20", 443, payload_type="fhir-r4-vitals", payload_size=512),
             "PatientMonitor-ICU-02 → EHR: Vital signs (HR, SpO2, BP)"),
            (Packet("PM-001", "10.0.40.10", 5000, payload_type="realtime-stream", payload_size=1024),
             "PatientMonitor-ICU-01 → ClinicalWS: Real-time waveform stream"),

            # Imaging → EHR (DICOM)
            (Packet("IS-001", "10.0.99.20", 443, payload_type="dicom-metadata", payload_size=4096),
             "MRI-Scanner-01 → EHR: DICOM study metadata"),
            (Packet("IS-002", "10.0.40.10", 104, payload_type="dicom-c-store", payload_size=65536),
             "CT-Scanner-01 → ClinicalWS: DICOM C-STORE (image transfer)"),

            # Admin → EHR (clinical access)
            (Packet("AW-001", "10.0.99.20", 443, payload_type="fhir-r4-query", payload_size=256),
             "ClinicalWorkstation-01 → EHR: Patient record query"),
            (Packet("AW-002", "10.0.99.20", 443, payload_type="fhir-r4-query", payload_size=256),
             "NurseStation-WS-01 → EHR: Patient record query"),
        ]

        for packet, description in normal_flows:
            if verbose:
                print(f"  {DIM}[{packet.timestamp[:19]}]{RESET} {description}")
            result = self.transmit(packet, description)
            if verbose:
                status = f"{GREEN}✓ ALLOWED{RESET}" if result else f"{RED}✗ BLOCKED{RESET}"
                print(f"  {' ' * 22}└─ Policy Decision: {status}\n")
            time.sleep(0.05)

    # ── Attack Scenario (Pre-ZTA) ─────────────────────────────────────────────

    def run_attack_without_zta(self, verbose: bool = True):
        """
        Simulate a lateral movement attack on a FLAT network
        (Zero Trust disabled). Demonstrates the vulnerability.
        """
        if verbose:
            print(f"\n{BOLD}{RED}{'═' * 65}{RESET}")
            print(f"{BOLD}{RED}  PHASE 2a: ATTACK ON FLAT NETWORK (NO ZERO TRUST){RESET}")
            print(f"{BOLD}{RED}{'═' * 65}{RESET}")
            print(f"\n  {YELLOW}Scenario: Infusion pump IP-001 is compromised.{RESET}")
            print(f"  {YELLOW}Attacker attempts lateral movement across VLANs.{RESET}\n")

        # Compromise the device for this scenario
        compromised = self.topology.get_device("IP-001")
        if compromised:
            compromised.compromised = True
            compromised.trust_score = 0.0

        flat_sim = IoMTSimulator(zero_trust_enabled=False)
        flat_sim.topology.get_device("IP-001").compromised = True

        attack_flows = [
            (Packet("IP-001", "10.0.20.11", 5000, payload_type="exploit-probe",
                    flags=["SYN", "ACK"], payload_size=64),
             "ATTACK: Compromised pump → PatientMonitor (recon probe)"),
            (Packet("IP-001", "10.0.30.11", 104, payload_type="dicom-exploit",
                    flags=["SYN"], payload_size=128),
             "ATTACK: Compromised pump → MRI Scanner (DICOM exploit)"),
            (Packet("IP-001", "10.0.40.10", 3389, payload_type="rdp-bruteforce",
                    flags=["SYN"], payload_size=64),
             "ATTACK: Compromised pump → Admin Workstation (RDP brute-force)"),
            (Packet("IP-001", "10.0.99.20", 443, payload_type="ehr-data-exfil",
                    flags=["SYN", "PSH"], payload_size=8192),
             "ATTACK: Compromised pump → EHR Server (PHI data exfiltration)"),
            (Packet("IP-001", "10.0.99.10", 8080, payload_type="gateway-exploit",
                    flags=["SYN"], payload_size=256),
             "ATTACK: Compromised pump → ZTA Gateway (gateway exploitation)"),
        ]

        for packet, description in attack_flows:
            if verbose:
                print(f"  {DIM}[{packet.timestamp[:19]}]{RESET} {description}")
            result = flat_sim.transmit(packet, description)
            if verbose:
                status = f"{RED}✗ ATTACK SUCCEEDED — DATA EXPOSED{RESET}"
                print(f"  {' ' * 22}└─ {status}\n")
            time.sleep(0.1)

        if verbose:
            print(f"  {RED}{BOLD}[!] All 5 attack vectors SUCCEEDED on flat network.{RESET}")
            print(f"  {RED}    Patient Health Information (PHI) exfiltrated!{RESET}\n")

    # ── Attack Scenario (Post-ZTA) ────────────────────────────────────────────

    def run_attack_with_zta(self, verbose: bool = True):
        """
        Simulate the SAME lateral movement attack with Zero Trust ENABLED.
        Demonstrates that ZTA blocks all unauthorized paths.
        """
        if verbose:
            print(f"\n{BOLD}{GREEN}{'═' * 65}{RESET}")
            print(f"{BOLD}{GREEN}  PHASE 2b: ATTACK WITH ZERO TRUST ENABLED{RESET}")
            print(f"{BOLD}{GREEN}{'═' * 65}{RESET}")
            print(f"\n  {CYAN}Same scenario: IP-001 compromised, Zero Trust active.{RESET}\n")

        # Compromise device in ZTA sim
        compromised = self.topology.get_device("IP-001")
        if compromised:
            compromised.compromised = True
            compromised.trust_score = 0.0
            compromised.authorized = False   # ZTA revokes authorization

        attack_flows = [
            (Packet("IP-001", "10.0.20.11", 5000, payload_type="exploit-probe",
                    flags=["SYN", "ACK"], payload_size=64),
             "ATTACK (ZTA): Compromised pump → PatientMonitor"),
            (Packet("IP-001", "10.0.30.11", 104, payload_type="dicom-exploit",
                    flags=["SYN"], payload_size=128),
             "ATTACK (ZTA): Compromised pump → MRI Scanner"),
            (Packet("IP-001", "10.0.40.10", 3389, payload_type="rdp-bruteforce",
                    flags=["SYN"], payload_size=64),
             "ATTACK (ZTA): Compromised pump → Admin Workstation"),
            (Packet("IP-001", "10.0.99.20", 443, payload_type="ehr-data-exfil",
                    flags=["SYN", "PSH"], payload_size=8192),
             "ATTACK (ZTA): Compromised pump → EHR Server"),
            (Packet("IP-001", "10.0.99.10", 8080, payload_type="gateway-exploit",
                    flags=["SYN"], payload_size=256),
             "ATTACK (ZTA): Compromised pump → ZTA Gateway"),
        ]

        for packet, description in attack_flows:
            if verbose:
                print(f"  {DIM}[{packet.timestamp[:19]}]{RESET} {description}")
            result = self.transmit(packet, description)
            if verbose:
                status = f"{GREEN}✓ ATTACK BLOCKED — Zero Trust Enforcement{RESET}"
                print(f"  {' ' * 22}└─ {status}\n")
            time.sleep(0.1)

        if verbose:
            print(f"  {GREEN}{BOLD}[✓] All 5 attack vectors BLOCKED by Zero Trust.{RESET}")
            print(f"  {GREEN}    No lateral movement. No PHI exfiltration.{RESET}\n")

    # ── Statistics ────────────────────────────────────────────────────────────

    def print_stats(self):
        print(f"\n{BOLD}{'─' * 50}{RESET}")
        print(f"{BOLD}  SIMULATION STATISTICS{RESET}")
        print(f"{'─' * 50}")
        print(f"  Packets Sent    : {self.stats['packets_sent']}")
        print(f"  {GREEN}Packets Allowed : {self.stats['packets_allowed']}{RESET}")
        print(f"  {RED}Packets Blocked : {self.stats['packets_blocked']}{RESET}")
        print(f"  {YELLOW}Attacks Detected: {self.stats['attacks_detected']}{RESET}")
        if self.stats['packets_sent'] > 0:
            block_pct = (self.stats['packets_blocked'] / self.stats['packets_sent']) * 100
            print(f"  Block Rate      : {block_pct:.1f}%")
        print(f"{'─' * 50}\n")


# ── Entry Point ────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="IoMT Zero Trust Simulator")
    parser.add_argument(
        "--mode",
        choices=["normal", "attack", "full", "demo"],
        default="full",
        help="Simulation mode (default: full)",
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress verbose output",
    )
    args = parser.parse_args()

    verbose = not args.quiet

    print(f"\n{BOLD}{BLUE}")
    print("  ╔══════════════════════════════════════════════════════╗")
    print("  ║     ZERO TRUST IoMT NETWORK SIMULATOR v2.1.0        ║")
    print("  ║     Healthcare Cybersecurity Research Platform       ║")
    print("  ╚══════════════════════════════════════════════════════╝")
    print(f"{RESET}")

    sim = IoMTSimulator(zero_trust_enabled=True)

    if verbose:
        sim.topology.print_summary()

    if args.mode in ("normal", "full", "demo"):
        sim.run_normal_traffic(verbose=verbose)

    if args.mode in ("attack", "full", "demo"):
        sim.run_attack_without_zta(verbose=verbose)
        time.sleep(0.5)
        sim.run_attack_with_zta(verbose=verbose)

    sim.print_stats()
    sim.logger.flush()

    if verbose:
        print(f"  {DIM}Logs saved to: logs/iomt_events.jsonl{RESET}\n")


if __name__ == "__main__":
    main()
